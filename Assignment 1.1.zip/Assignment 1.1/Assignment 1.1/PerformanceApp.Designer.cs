﻿namespace Assignment_1._1
{
    partial class PerformanceApp
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        // UI controls
        private System.Windows.Forms.TextBox SizeInput;
        private System.Windows.Forms.Button StartProcess;
        private System.Windows.Forms.Label GenResult;
        private System.Windows.Forms.Label SortResult;

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.SizeInput = new System.Windows.Forms.TextBox();
            this.StartProcess = new System.Windows.Forms.Button();
            this.GenResult = new System.Windows.Forms.Label();
            this.SortResult = new System.Windows.Forms.Label();

            this.SuspendLayout();

            // SizeInput
            this.SizeInput.Location = new System.Drawing.Point(20, 20);
            this.SizeInput.Name = "SizeInput";
            this.SizeInput.Size = new System.Drawing.Size(200, 23);
            this.SizeInput.TabIndex = 0;
            this.SizeInput.Text = "1000";

            // StartProcess
            this.StartProcess.Location = new System.Drawing.Point(240, 18);
            this.StartProcess.Name = "StartProcess";
            this.StartProcess.Size = new System.Drawing.Size(120, 26);
            this.StartProcess.TabIndex = 1;
            this.StartProcess.Text = "Start";
            this.StartProcess.UseVisualStyleBackColor = true;
            this.StartProcess.Click += new System.EventHandler(this.StartProcess_Click);

            // GenResult
            this.GenResult.Location = new System.Drawing.Point(20, 60);
            this.GenResult.Name = "GenResult";
            this.GenResult.Size = new System.Drawing.Size(400, 23);
            this.GenResult.TabIndex = 2;
            this.GenResult.Text = "Generation Time: " ;

            // SortResult
            this.SortResult.Location = new System.Drawing.Point(20, 90);
            this.SortResult.Name = "SortResult";
            this.SortResult.Size = new System.Drawing.Size(400, 23);
            this.SortResult.TabIndex = 3;
            this.SortResult.Text = "Sort Time: ";

            // PerformanceApp Form
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 160);
            this.Controls.Add(this.SizeInput);
            this.Controls.Add(this.StartProcess);
            this.Controls.Add(this.GenResult);
            this.Controls.Add(this.SortResult);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "PerformanceApp";
            this.Text = "Performance App";

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
