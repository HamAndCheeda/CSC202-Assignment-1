using System;
using System.Diagnostics; // Required for Stopwatch
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Drawing;

namespace Assignment_1._1
{
    public partial class PerformanceApp : Form
    {
        public PerformanceApp() => InitializeComponent();

        private async void StartProcess_Click(object sender, EventArgs e)
        {
            // Cast the sender to a Button so we can disable it while work runs.
            var button = sender as Button;

            // 1. Validation: ensure the user entered an integer in (0, 100000)
            if (!int.TryParse(SizeInput.Text, out int size) || size <= 0 || size >= 100000)
            {
                MessageBox.Show("Please enter a number between 1 and 99,999.");
                return;
            }

            // Disable the button to prevent repeated clicks while processing.
            if (button != null)
                button.Enabled = false;

            try
            {
                // Run the generation and sorting on a background thread so the UI remains responsive.
                var (genMs, sortMs) = await Task.Run(() =>
                {
                    // 2. Setup: allocate array and random number generator.
                    int[] numbers = new int[size];
                    Random rand = new Random();
                    Stopwatch sw = new Stopwatch();

                    // 3. Time the Generation: fill the array with random non-negative integers.
                    sw.Start();
                    for (int i = 0; i < size; i++)
                    {
                        numbers[i] = rand.Next();
                    }
                    sw.Stop();
                    double genTimeMs = sw.Elapsed.TotalMilliseconds;

                    // 4. Time the Sorting: sort the previously generated array.
                    sw.Restart();
                    Array.Sort(numbers);
                    sw.Stop();
                    double sortTimeMs = sw.Elapsed.TotalMilliseconds;

                    // Return the measured times to the UI thread.
                    return (genTimeMs, sortTimeMs);
                });

                // Update UI with the results. Use concise, human-readable formatting.
                GenResult.Text = $"Generation Time: {genMs:F3} ms (array size: {size})";
                SortResult.Text = $"Sort Time: {sortMs:F3} ms";
            }
            finally
            {
                // Re-enable the button even if an exception occurred.
                if (button != null)
                    button.Enabled = true;
            }
        }
    }
}