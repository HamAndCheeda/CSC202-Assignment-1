﻿namespace CalculatorApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            num1 = new Button();
            calculatorDisplay = new Label();
            num2 = new Button();
            num3 = new Button();
            num4 = new Button();
            num5 = new Button();
            num6 = new Button();
            num7 = new Button();
            num8 = new Button();
            num9 = new Button();
            this.equalButton = new Button();
            this.plusButton = new Button();
            minusButton = new Button();
            divideButton = new Button();
            multiplyButton = new Button();
            zerobutton = new Button();
            decimalButton = new Button();
            clearButton = new Button();
            SuspendLayout();
            // 
            // num1
            // 
            num1.BackColor = SystemColors.ControlDark;
            num1.Font = new Font("Microsoft Sans Serif", 16.2F);
            num1.Location = new Point(8, 147);
            num1.Name = "num1";
            num1.Size = new Size(94, 60);
            num1.TabIndex = 0;
            num1.Text = "1";
            num1.UseVisualStyleBackColor = false;
            num1.Click += num1_Click;
            // 
            // calculatorDisplay
            // 
            calculatorDisplay.BackColor = SystemColors.ActiveCaptionText;
            calculatorDisplay.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point, 0);
            calculatorDisplay.ForeColor = SystemColors.ButtonHighlight;
            calculatorDisplay.Location = new Point(8, 7);
            calculatorDisplay.Name = "calculatorDisplay";
            calculatorDisplay.Size = new Size(374, 71);
            calculatorDisplay.TabIndex = 3;
            calculatorDisplay.Text = "0\r\n";
            // 
            // num2
            // 
            num2.BackColor = SystemColors.ControlDark;
            num2.Font = new Font("Microsoft Sans Serif", 16.2F);
            num2.Location = new Point(97, 147);
            num2.Name = "num2";
            num2.Size = new Size(94, 60);
            num2.TabIndex = 4;
            num2.Text = "2";
            num2.UseVisualStyleBackColor = false;
            num2.Click += num2_Click;
            // 
            // num3
            // 
            num3.BackColor = SystemColors.ControlDark;
            num3.Font = new Font("Microsoft Sans Serif", 16.2F);
            num3.Location = new Point(188, 147);
            num3.Name = "num3";
            num3.Size = new Size(94, 60);
            num3.TabIndex = 5;
            num3.Text = "3";
            num3.UseVisualStyleBackColor = false;
            num3.Click += num3_Click;
            // 
            // num4
            // 
            num4.BackColor = SystemColors.ControlDark;
            num4.Font = new Font("Microsoft Sans Serif", 16.2F);
            num4.Location = new Point(8, 213);
            num4.Name = "num4";
            num4.Size = new Size(94, 60);
            num4.TabIndex = 6;
            num4.Text = "4";
            num4.UseVisualStyleBackColor = false;
            num4.Click += num4_Click;
            // 
            // num5
            // 
            num5.BackColor = SystemColors.ControlDark;
            num5.Font = new Font("Microsoft Sans Serif", 16.2F);
            num5.Location = new Point(97, 213);
            num5.Name = "num5";
            num5.Size = new Size(94, 60);
            num5.TabIndex = 7;
            num5.Text = "5";
            num5.UseVisualStyleBackColor = false;
            num5.Click += num5_Click;
            // 
            // num6
            // 
            num6.BackColor = SystemColors.ControlDark;
            num6.Font = new Font("Microsoft Sans Serif", 16.2F);
            num6.Location = new Point(188, 213);
            num6.Name = "num6";
            num6.Size = new Size(94, 60);
            num6.TabIndex = 8;
            num6.Text = "6";
            num6.UseVisualStyleBackColor = false;
            num6.Click += num6_Click;
            // 
            // num7
            // 
            num7.BackColor = SystemColors.ControlDark;
            num7.Font = new Font("Microsoft Sans Serif", 16.2F);
            num7.Location = new Point(8, 279);
            num7.Name = "num7";
            num7.Size = new Size(94, 60);
            num7.TabIndex = 9;
            num7.Text = "7";
            num7.UseVisualStyleBackColor = false;
            num7.Click += num7_Click;
            // 
            // num8
            // 
            num8.BackColor = SystemColors.ControlDark;
            num8.Font = new Font("Microsoft Sans Serif", 16.2F);
            num8.Location = new Point(97, 279);
            num8.Name = "num8";
            num8.Size = new Size(94, 60);
            num8.TabIndex = 10;
            num8.Text = "8";
            num8.UseVisualStyleBackColor = false;
            num8.Click += num8_Click;
            // 
            // num9
            // 
            num9.BackColor = SystemColors.ControlDark;
            num9.Font = new Font("Microsoft Sans Serif", 16.2F);
            num9.Location = new Point(188, 279);
            num9.Name = "num9";
            num9.Size = new Size(94, 60);
            num9.TabIndex = 11;
            num9.Text = "9";
            num9.UseVisualStyleBackColor = false;
            num9.Click += num9_Click;
            // 
            // equalButton
            // 
            this.equalButton.BackColor = SystemColors.ControlDark;
            this.equalButton.Font = new Font("Microsoft Sans Serif", 16.2F);
            this.equalButton.Location = new Point(288, 279);
            this.equalButton.Name = "equalButton";
            this.equalButton.Size = new Size(94, 126);
            this.equalButton.TabIndex = 13;
            this.equalButton.Text = "=";
            this.equalButton.UseVisualStyleBackColor = false;
            this.equalButton.Click += this.equalButton_Click;
            // 
            // plusButton
            // 
            this.plusButton.BackColor = SystemColors.ControlDark;
            this.plusButton.Font = new Font("Microsoft Sans Serif", 16.2F);
            this.plusButton.Location = new Point(288, 147);
            this.plusButton.Name = "plusButton";
            this.plusButton.Size = new Size(94, 60);
            this.plusButton.TabIndex = 14;
            this.plusButton.Text = "+";
            this.plusButton.UseVisualStyleBackColor = false;
            this.plusButton.Click += this.plusButton_Click;
            // 
            // minusButton
            // 
            minusButton.BackColor = SystemColors.ControlDark;
            minusButton.Font = new Font("Microsoft Sans Serif", 16.2F);
            minusButton.Location = new Point(288, 213);
            minusButton.Name = "minusButton";
            minusButton.Size = new Size(94, 60);
            minusButton.TabIndex = 15;
            minusButton.Text = "-";
            minusButton.UseVisualStyleBackColor = false;
            minusButton.Click += minusButton_Click;
            // 
            // divideButton
            // 
            divideButton.BackColor = SystemColors.ControlDark;
            divideButton.Font = new Font("Microsoft Sans Serif", 16.2F);
            divideButton.Location = new Point(188, 81);
            divideButton.Name = "divideButton";
            divideButton.Size = new Size(94, 60);
            divideButton.TabIndex = 16;
            divideButton.Text = "/";
            divideButton.UseVisualStyleBackColor = false;
            divideButton.Click += divideButton_Click;
            // 
            // multiplyButton
            // 
            multiplyButton.BackColor = SystemColors.ControlDark;
            multiplyButton.Font = new Font("Microsoft Sans Serif", 16.2F);
            multiplyButton.Location = new Point(288, 81);
            multiplyButton.Name = "multiplyButton";
            multiplyButton.Size = new Size(94, 60);
            multiplyButton.TabIndex = 17;
            multiplyButton.Text = "x";
            multiplyButton.UseVisualStyleBackColor = false;
            multiplyButton.Click += multiplyButton_Click;
            // 
            // zerobutton
            // 
            zerobutton.BackColor = SystemColors.ControlDark;
            zerobutton.Font = new Font("Microsoft Sans Serif", 16.2F);
            zerobutton.Location = new Point(8, 345);
            zerobutton.Name = "zerobutton";
            zerobutton.Size = new Size(183, 60);
            zerobutton.TabIndex = 18;
            zerobutton.Text = "0";
            zerobutton.UseVisualStyleBackColor = false;
            zerobutton.Click += zerobutton_Click;
            // 
            // decimalButton
            // 
            decimalButton.BackColor = SystemColors.ControlDark;
            decimalButton.Font = new Font("Microsoft Sans Serif", 16.2F);
            decimalButton.Location = new Point(188, 345);
            decimalButton.Name = "decimalButton";
            decimalButton.Size = new Size(94, 60);
            decimalButton.TabIndex = 20;
            decimalButton.Text = ".";
            decimalButton.UseVisualStyleBackColor = false;
            decimalButton.Click += decimalButton_Click;
            // 
            // clearButton
            // 
            clearButton.BackColor = SystemColors.ControlDark;
            clearButton.Font = new Font("Microsoft Sans Serif", 16.2F);
            clearButton.Location = new Point(8, 81);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(183, 60);
            clearButton.TabIndex = 21;
            clearButton.Text = "AC";
            clearButton.UseVisualStyleBackColor = false;
            clearButton.Click += clearButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(390, 411);
            Controls.Add(clearButton);
            Controls.Add(decimalButton);
            Controls.Add(zerobutton);
            Controls.Add(multiplyButton);
            Controls.Add(divideButton);
            Controls.Add(minusButton);
            Controls.Add(this.plusButton);
            Controls.Add(this.equalButton);
            Controls.Add(num9);
            Controls.Add(num8);
            Controls.Add(num7);
            Controls.Add(num6);
            Controls.Add(num5);
            Controls.Add(num4);
            Controls.Add(num3);
            Controls.Add(num2);
            Controls.Add(calculatorDisplay);
            Controls.Add(num1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button num1;
        private Label calculatorDisplay;
        private Button num2;
        private Button num3;
        private Button num4;
        private Button num5;
        private Button num6;
        private Button num7;
        private Button num8;
        private Button num9;
        private Button equalButton;
        private Button plusButton;
        private Button minusButton;
        private Button divideButton;
        private Button multiplyButton;
        private Button zerobutton;
        private Button decimalButton;
        private Button clearButton;
    }
}
