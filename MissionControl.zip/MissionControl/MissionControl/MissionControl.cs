using System;
using System.Drawing;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;

namespace MissionControl
{
    public partial class MissionControl : Form
    {
        // Theme Colors
        private readonly Color spaceBlue = Color.FromArgb(26, 26, 46);
        private readonly Color neonPink = Color.FromArgb(233, 69, 96);
        private readonly Color nebulaGreen = Color.FromArgb(78, 204, 163);

        private readonly string configPath = "settings.json";
        private readonly string logPath = "mission_logs.txt";

        // UI Elements
        private TextBox nameEntry = null!;
        private TextBox logEntry = null!;

        public MissionControl()
        {
            // Ensure designer-initialized components are created first
            InitializeComponent();

            this.Text = "NEBULA MISSION CONTROL";
            this.Size = new Size(450, 550);
            this.BackColor = spaceBlue;
            this.ForeColor = Color.White;
            this.Font = new Font("Courier New", 10);

            InitializeCustomUI();
            LoadConfig();
        }

        private void InitializeCustomUI()
        {
            // Header
            Label header = new Label
            {
                Text = "--- SYSTEM ONLINE ---",
                ForeColor = neonPink,
                Font = new Font("Courier New", 14, FontStyle.Bold),
                Dock = DockStyle.Top,
                TextAlign = ContentAlignment.MiddleCenter,
                Height = 60
            };

            // Commander Name Section
            Label nameLabel = new Label { Text = "Commander Name:", Top = 70, Left = 50, Width = 350 };
            nameEntry = new TextBox
            {
                Top = 95,
                Left = 50,
                Width = 330,
                BackColor = Color.FromArgb(15, 52, 96),
                ForeColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle
            };

            Button saveConfigBtn = new Button
            {
                Text = "SAVE PERMISSION LEVELS",
                Top = 130,
                Left = 50,
                Width = 330,
                Height = 35,
                BackColor = neonPink,
                FlatStyle = FlatStyle.Flat
            };
            saveConfigBtn.Click += (s, e) => SaveConfig();

            // Log Section
            Label logLabel = new Label { Text = "New Status Report:", Top = 190, Left = 50, Width = 350 };
            logEntry = new TextBox
            {
                Top = 215,
                Left = 50,
                Width = 330,
                Height = 100,
                Multiline = true,
                BackColor = Color.FromArgb(22, 33, 62),
                ForeColor = nebulaGreen,
                BorderStyle = BorderStyle.FixedSingle
            };

            Button transmitBtn = new Button
            {
                Text = "TRANSMIT LOG",
                Top = 330,
                Left = 50,
                Width = 330,
                Height = 35,
                BackColor = nebulaGreen,
                ForeColor = spaceBlue,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Courier New", 10, FontStyle.Bold)
            };
            transmitBtn.Click += (s, e) => WriteLog();

            Button readLogBtn = new Button
            {
                Text = "RECALL MISSION HISTORY",
                Top = 375,
                Left = 50,
                Width = 330,
                Height = 35,
                BackColor = Color.FromArgb(15, 52, 96),
                FlatStyle = FlatStyle.Flat
            };
            readLogBtn.Click += (s, e) => ReadLogs();

            // Add controls to form
            this.Controls.AddRange(new Control[] {
                header, nameLabel, nameEntry, saveConfigBtn,
                logLabel, logEntry, transmitBtn, readLogBtn
            });
        }

        private void SaveConfig()
        {
            var data = new { Commander = nameEntry.Text, LastUpdate = DateTime.Now };
            string json = JsonSerializer.Serialize(data);
            File.WriteAllText(configPath, json);
            MessageBox.Show("Configuration Uploaded to Core.", "System");
        }

        private void LoadConfig()
        {
            if (File.Exists(configPath))
            {
                string json = File.ReadAllText(configPath);
                using (JsonDocument doc = JsonDocument.Parse(json))
                {
                    nameEntry.Text = doc.RootElement.GetProperty("Commander").GetString();
                }
            }
            else { nameEntry.Text = "Unknown_Entity"; }
        }

        private void WriteLog()
        {
            if (!string.IsNullOrWhiteSpace(logEntry.Text))
            {
                string entry = $"[{DateTime.Now}] {logEntry.Text}{Environment.NewLine}";
                File.AppendAllText(logPath, entry);
                logEntry.Clear();
                MessageBox.Show("Log encrypted and stored.", "System");
            }
        }

        private void ReadLogs()
        {
            if (File.Exists(logPath))
            {
                string history = File.ReadAllText(logPath);
                Form logWindow = new Form
                {
                    Text = "Mission History",
                    Width = 400,
                    Height = 400,
                    BackColor = spaceBlue
                };
                TextBox display = new TextBox
                {
                    Multiline = true,
                    Dock = DockStyle.Fill,
                    ReadOnly = true,
                    Text = history,
                    BackColor = spaceBlue,
                    ForeColor = nebulaGreen,
                    BorderStyle = BorderStyle.None,
                    ScrollBars = ScrollBars.Vertical
                };
                logWindow.Controls.Add(display);
                logWindow.Show();
            }
            else { MessageBox.Show("No mission logs exist yet.", "Error"); }
        }
    }
}