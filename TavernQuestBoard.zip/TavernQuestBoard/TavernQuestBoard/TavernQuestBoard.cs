namespace TavernQuestBoard
{
    /// <summary>
    /// Represents a quest posted on the tavern quest board.
    /// This simple data-holding class contains a few properties that describe
    /// the quest and a couple of helper methods used by the UI.
    /// </summary>
    public class Quest
    {
        // --- Properties ---
        // The displayed title of the quest
        public string Title { get; set; }

        // Difficulty level (for example: "Easy", "Medium", "Hard")
        public string Difficulty { get; set; }

        // Reward amount in gold coins
        public int RewardGold { get; set; }

        // Name of the NPC or entity that posted the quest
        public string QuestGiver { get; set; }

        // Marks the quest as urgent (used to highlight listings)
        public bool IsUrgent { get; set; }

        /// <summary>
        /// Create a new Quest instance.
        /// </summary>
        public Quest(string title, string difficulty, int reward, string giver, bool urgent)
        {
            Title = title;
            Difficulty = difficulty;
            RewardGold = reward;
            QuestGiver = giver;
            IsUrgent = urgent;
        }

        /// <summary>
        /// Returns a short one-line summary suitable for display in a list box.
        /// Example: "[URGENT] Dragon Slaying (Hard) - Giver: King | Reward: 5000g"
        /// </summary>
        public string GetSummary()
        {
            string urgencyTag = IsUrgent ? "[URGENT] " : "";
            return $"{urgencyTag}{Title} ({Difficulty}) - Giver: {QuestGiver} | Reward: {RewardGold}g";
        }

        /// <summary>
        /// Calculate a simple "insurance" or risk premium based on difficulty.
        /// This is just an example computation used to demonstrate methods on the data class.
        /// </summary>
        public double CalculateInsurance()
        {
            return Difficulty == "Hard" ? RewardGold * 0.2 : RewardGold * 0.05;
        }
    }
}
