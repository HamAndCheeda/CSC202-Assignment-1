﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace TavernQuestBoard
{
    partial class QuestBoardForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private TextBox txtTitle;
        private ComboBox comboDifficulty;
        private NumericUpDown numGold;
        private TextBox txtGiver;
        private CheckBox chkUrgent;
        private Button btnAddQuest;
        private ListBox listBoxQuests;
        private Label lblInstructions;
        private ToolTip toolTip1;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new Container();
            this.txtTitle = new TextBox();
            this.comboDifficulty = new ComboBox();
            this.numGold = new NumericUpDown();
            this.txtGiver = new TextBox();
            this.chkUrgent = new CheckBox();
            this.btnAddQuest = new Button();
            this.listBoxQuests = new ListBox();

            ((ISupportInitialize)(this.numGold)).BeginInit();

            // Form
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(800, 450);
            this.Text = "Tavern Quest Board";

            // txtTitle
            this.txtTitle.Location = new Point(12, 12);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new Size(200, 23);
            this.txtTitle.PlaceholderText = "Quest Title";

            // comboDifficulty
            this.comboDifficulty.Location = new Point(12, 44);
            this.comboDifficulty.Name = "comboDifficulty";
            this.comboDifficulty.Size = new Size(120, 23);
            this.comboDifficulty.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboDifficulty.Items.AddRange(new object[] { "Easy", "Medium", "Hard" });
            this.comboDifficulty.SelectedIndex = 0;

            // numGold
            this.numGold.Location = new Point(140, 44);
            this.numGold.Name = "numGold";
            this.numGold.Size = new Size(72, 23);
            this.numGold.Minimum = 0;
            this.numGold.Maximum = 1000000;

            // txtGiver
            this.txtGiver.Location = new Point(12, 76);
            this.txtGiver.Name = "txtGiver";
            this.txtGiver.Size = new Size(200, 23);
            this.txtGiver.PlaceholderText = "Quest Giver";

            // chkUrgent
            this.chkUrgent.Location = new Point(12, 108);
            this.chkUrgent.Name = "chkUrgent";
            this.chkUrgent.Size = new Size(80, 24);
            this.chkUrgent.Text = "Urgent";

            // btnAddQuest
            this.btnAddQuest.Location = new Point(12, 138);
            this.btnAddQuest.Name = "btnAddQuest";
            this.btnAddQuest.Size = new Size(100, 30);
            this.btnAddQuest.Text = "Add Quest";
            this.btnAddQuest.Click += new EventHandler(this.btnAddQuest_Click);

            // listBoxQuests
            this.listBoxQuests.Location = new Point(230, 12);
            this.listBoxQuests.Name = "listBoxQuests";
            this.listBoxQuests.Size = new Size(550, 420);

            // lblInstructions
            // A short set of instructions to help the user know how to use the UI
            this.lblInstructions = new Label();
            this.lblInstructions.Location = new Point(12, 180);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new Size(200, 120);
            this.lblInstructions.AutoSize = false;
            this.lblInstructions.Text = "Instructions:\r\n- Enter a quest title.\r\n- Choose difficulty and reward gold.\r\n- Enter the quest giver.\r\n- Check \"Urgent\" if the quest is urgent.\r\n- Click 'Add Quest' to add it to the list on the right.";
            this.lblInstructions.Font = new Font(this.lblInstructions.Font.FontFamily, 9);

            // toolTip1
            this.toolTip1 = new ToolTip(this.components);
            this.toolTip1.SetToolTip(this.btnAddQuest, "Click to add the quest with the information above");

            // Add controls to form (including an instructions label so users know what to do)
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.comboDifficulty);
            this.Controls.Add(this.numGold);
            this.Controls.Add(this.txtGiver);
            this.Controls.Add(this.chkUrgent);
            this.Controls.Add(this.btnAddQuest);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.listBoxQuests);

            ((ISupportInitialize)(this.numGold)).EndInit();
        }

        #endregion
    }
}
