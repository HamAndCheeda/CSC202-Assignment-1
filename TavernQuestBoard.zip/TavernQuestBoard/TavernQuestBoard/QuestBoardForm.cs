using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace TavernQuestBoard
{
    /// <summary>
    /// Main form for the Tavern Quest Board application.
    /// The form allows a user to create simple Quest objects and view them in a list.
    /// This partial class contains the logic; the designer partial contains the UI field definitions.
    /// </summary>
    internal partial class QuestBoardForm : Form
    {
        // Internal in-memory collection of quests displayed on the board.
        // In a real application this might be persisted to a database or file.
        List<Quest> questList = new List<Quest>();

    public QuestBoardForm()
    {
        InitializeComponent();
        SeedInitialData(); // Create initial objects to show it works
    }

    private void SeedInitialData()
    {
        // Creating 5 initial Quest objects to demonstrate functionality and show the list is working
        questList.Add(new Quest("Slime Infestation", "Easy", 50, "Mayor", false));
        questList.Add(new Quest("Dragon Slaying", "Hard", 5000, "King", true));
        questList.Add(new Quest("Lost Cat", "Easy", 5, "Old Lady", false));
        questList.Add(new Quest("Mine Collapse", "Medium", 200, "Guild Master", true));
        questList.Add(new Quest("Potion Delivery", "Easy", 25, "Alchemist", false));

        UpdateDisplay();
    }

    private void btnAddQuest_Click(object sender, EventArgs e)
    {
        // Capture user input from the GUI (use Controls.Find so code still builds when designer fields are missing).
        // In the typical Visual Studio generated code the form's partial class would contain
        // direct fields like txtTitle and comboDifficulty; Controls.Find is a safe fallback.
        var txtTitle = this.Controls.Find("txtTitle", true).FirstOrDefault() as TextBox;
        string title = txtTitle != null ? txtTitle.Text : "Untitled";

        var comboDifficulty = this.Controls.Find("comboDifficulty", true).FirstOrDefault() as ComboBox;
        string diff = comboDifficulty?.SelectedItem?.ToString() ?? "Easy";

        var numGold = this.Controls.Find("numGold", true).FirstOrDefault() as NumericUpDown;
        int gold = numGold != null ? (int)numGold.Value : 0;

        var txtGiver = this.Controls.Find("txtGiver", true).FirstOrDefault() as TextBox;
        string giver = txtGiver != null ? txtGiver.Text : "Unknown";

        var chkUrgent = this.Controls.Find("chkUrgent", true).FirstOrDefault() as CheckBox;
        bool urgent = chkUrgent != null && chkUrgent.Checked;

        // Instantiate a new object
        Quest newQuest = new Quest(title, diff, gold, giver, urgent);

        // Add to the collection
        questList.Add(newQuest);

        UpdateDisplay();
    }

    private void UpdateDisplay()
    {
        // Find the listbox that displays quests and refresh its items from the questList
        var listBox = this.Controls.Find("listBoxQuests", true).FirstOrDefault() as ListBox;
        if (listBox == null)
            return;

        listBox.Items.Clear();
        foreach (Quest q in questList)
        {
            // Using the class method to display information
            listBox.Items.Add(q.GetSummary());
        }
    }
    }
}
