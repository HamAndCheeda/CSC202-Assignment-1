using System;
using System.Windows.Forms;
using System.Linq;

namespace DnDTracker
{
    public partial class DnDTracker : Form
    {
        // ---------------------------------------------------------
        // 1. DATA STORAGE (ARRAYS)
        // ---------------------------------------------------------

        // String array to store adventurer names
        private string[] characterNames = new string[10];

        // Integer array to store corresponding Hit Points (HP)
        private int[] hitPoints = new int[10];

        // Counter to track how many heroes are currently in the party array
        private int playerCount = 0;

        public DnDTracker()
        {
            InitializeComponent();
            SetupManualUI(); // Initializes the visual interface
        }

        private void btnAddHero_Click(object sender, EventArgs e)
        {
            // ---------------------------------------------------------
            // 2. EXCEPTION / ERROR HANDLING
            // ---------------------------------------------------------
            try
            {
                // Logic Check: Prevent adding more than the array's capacity
                if (playerCount >= 10)
                {
                    throw new Exception("The party is full! Only 10 heroes allowed.");
                }

                string name = txtName.Text.Trim();

                // Logic Check: Ensure the name string is not empty
                if (string.IsNullOrEmpty(name))
                {
                    throw new ArgumentException("A hero must have a name to be remembered.");
                }

                // Attempt to parse the HP input string into an Integer
                // This will throw a FormatException if the user types letters instead of numbers
                int hp = int.Parse(txtHP.Text);

                // Logic Check: Ensure HP is a positive value
                if (hp < 1)
                {
                    throw new ArgumentOutOfRangeException("HP", "A hero must start with at least 1 HP.");
                }

                // ---------------------------------------------------------
                // 3. UTILIZING THE ARRAYS
                // ---------------------------------------------------------

                // Store the string in the characterNames array at the current index
                characterNames[playerCount] = name;

                // Store the integer in the hitPoints array at the same index
                hitPoints[playerCount] = hp;

                // Increment the counter so the next hero goes into the next slot
                playerCount++;

                UpdateDisplay();
                ClearInputs();
            }
            catch (FormatException)
            {
                // Specifically catches cases where int.Parse() fails (e.g., user enters "abc")
                MessageBox.Show("Please enter a valid whole number for Hit Points.", "Roll for Intelligence!");
            }
            catch (Exception ex)
            {
                // Catches all other custom errors (Party full, empty name, etc.)
                MessageBox.Show(ex.Message, "Dungeon Error");
            }
        }

        private void btnTakeDamage_Click(object sender, EventArgs e)
        {
            // UTILIZING THE INTEGER ARRAY:
            // Loop through the active portion of the array to apply a "Fireball" (damage)
            for (int i = 0; i < playerCount; i++)
            {
                if (hitPoints[i] > 0)
                {
                    // Subtract 10 from the integer value stored in the array
                    hitPoints[i] -= 10;

                    // Logic: HP cannot be lower than 0 (Death saves!)
                    if (hitPoints[i] < 0) hitPoints[i] = 0;
                }
            }
            UpdateDisplay();
        }

        private void UpdateDisplay()
        {
            // Clear the visual list before refreshing
            lstParty.Items.Clear();

            // UTILIZING BOTH ARRAYS:
            // Iterate through the party and pull data from both arrays simultaneously
            for (int i = 0; i < playerCount; i++)
            {
                // Determine status based on the integer array value
                string status = hitPoints[i] > 0 ? "ALIVE" : "DOWNED";

                // Combine the status, the string array name, and the integer array HP
                lstParty.Items.Add($"[{status}] {characterNames[i]} - HP: {hitPoints[i]}");
            }
        }

        private void ClearInputs()
        {
            txtName.Clear();
            txtHP.Clear();
            txtName.Focus();
        }

        // --- UI Setup (Standard WinForms boilerplate) ---
        private TextBox txtName = null!;
        private TextBox txtHP = null!;
        private ListBox lstParty = null!;
        private Button btnAdd = null!;
        private Button btnDamage = null!;

        private void SetupManualUI()
        {
            this.Text = "D&D Party Tracker";
            this.Size = new System.Drawing.Size(400, 450);

            Label lblName = new Label { Text = "Hero Name:", Left = 20, Top = 20 };
            txtName = new TextBox { Left = 120, Top = 20, Width = 150 };

            Label lblHP = new Label { Text = "Starting HP:", Left = 20, Top = 50 };
            txtHP = new TextBox { Left = 120, Top = 50, Width = 50 };

            btnAdd = new Button { Text = "Add Hero", Left = 120, Top = 90, Width = 150 };
            btnAdd.Click += btnAddHero_Click;

            btnDamage = new Button { Text = "Apply 10 Damage", Left = 120, Top = 120, Width = 150 };
            btnDamage.Click += btnTakeDamage_Click;

            lstParty = new ListBox { Left = 20, Top = 160, Width = 340, Height = 180 };

            this.Controls.Add(lblName); this.Controls.Add(txtName);
            this.Controls.Add(lblHP); this.Controls.Add(txtHP);
            this.Controls.Add(btnAdd); this.Controls.Add(btnDamage);
            this.Controls.Add(lstParty);
        }
    }
}