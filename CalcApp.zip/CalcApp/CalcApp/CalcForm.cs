using System;
using System.Drawing;
using System.Windows.Forms;

namespace CalculatorApp
{
    public class CalcForm : Form
    {
        // UI Components
        private TextBox txtNumber1;
        private TextBox txtNumber2;
        private Button btnAdd;
        private Button btnSubtract;
        private Button btnMultiply;
        private Button btnDivide;
        private Label lblResult;
        private Panel calcBody;

        public CalcForm()
        {
            // Main Form Settings
            this.Text = "QuickCalc C#";
            this.Size = new Size(300, 400);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            // 1. Panel (GUI Component #1) - The calculator body
            calcBody = new Panel();
            calcBody.Size = new Size(260, 340);
            calcBody.Location = new Point(12, 12);
            calcBody.BorderStyle = BorderStyle.Fixed3D;
            calcBody.BackColor = Color.LightGray;

            // 2. Textboxes for User Input
            txtNumber1 = new TextBox();
            txtNumber1.Location = new Point(30, 30);
            txtNumber1.Width = 200;
            txtNumber1.PlaceholderText = "First Number";

            txtNumber2 = new TextBox();
            txtNumber2.Location = new Point(30, 70);
            txtNumber2.Width = 200;
            txtNumber2.PlaceholderText = "Second Number";

            // 3. Operation Buttons (+, -, *, /)
            btnAdd = new Button();
            btnAdd.Text = "+";
            btnAdd.Location = new Point(30, 120);
            btnAdd.Size = new Size(95, 40);
            btnAdd.Font = new Font("Arial", 12, FontStyle.Bold);

            btnSubtract = new Button();
            btnSubtract.Text = "-";
            btnSubtract.Location = new Point(135, 120);
            btnSubtract.Size = new Size(95, 40);
            btnSubtract.Font = new Font("Arial", 12, FontStyle.Bold);

            btnMultiply = new Button();
            btnMultiply.Text = "�";
            btnMultiply.Location = new Point(30, 170);
            btnMultiply.Size = new Size(95, 40);
            btnMultiply.Font = new Font("Arial", 12, FontStyle.Bold);

            btnDivide = new Button();
            btnDivide.Text = "�";
            btnDivide.Location = new Point(135, 170);
            btnDivide.Size = new Size(95, 40);
            btnDivide.Font = new Font("Arial", 12, FontStyle.Bold);

            // 4. Label (GUI Component #2) - To show the result
            lblResult = new Label();
            lblResult.Text = "Result: 0";
            lblResult.Location = new Point(30, 240);
            lblResult.Size = new Size(200, 50);
            lblResult.TextAlign = ContentAlignment.MiddleCenter;
            lblResult.BackColor = Color.Black;
            lblResult.ForeColor = Color.LimeGreen;
            lblResult.Font = new Font("Consolas", 14, FontStyle.Bold);

            // Adding everything to the Panel
            calcBody.Controls.Add(txtNumber1);
            calcBody.Controls.Add(txtNumber2);
            calcBody.Controls.Add(btnAdd);
            calcBody.Controls.Add(btnSubtract);
            calcBody.Controls.Add(btnMultiply);
            calcBody.Controls.Add(btnDivide);
            calcBody.Controls.Add(lblResult);

            // Adding Panel to the Form
            this.Controls.Add(calcBody);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new CalcForm());
        }
    }
}