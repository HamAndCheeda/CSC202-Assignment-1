# Copilot Instructions

## General Guidelines
- Use concise, impersonal fixes.
- Ensure designer files contain only UI wiring (InitializeComponent and control fields).
- Logic and validation should reside in the code-behind (e.g., TravelCalculatorForm.cs).

## Code Style
- Follow specific formatting rules.
- Adhere to naming conventions.