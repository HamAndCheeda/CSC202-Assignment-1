﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace GalacticTravelAgency
{
    internal class ManifestForm : Form
    {
        // Shared list to store names (BindingList notifies UI on changes)
        private readonly BindingList<string> passengerList;

        // UI controls
        private ListBox? lstPassengers;
        private TextBox? txtNewPassenger;
        private Button? btnAddTraveler;

        // Accept an optional shared list; if null, create a default one
        public ManifestForm(BindingList<string>? sharedList = null)
        {
            // Conditional Block #1: choose the incoming shared list or instantiate a default list.
            // This uses the null-coalescing operator to select between provided and default data.
            passengerList = sharedList ?? new BindingList<string> { "Zaphod Beeblebrox", "Ford Prefect", "Arthur Dent" };

            InitializeComponent();

            // bind the list to the listbox so updates are live
            if (lstPassengers != null)
                lstPassengers.DataSource = passengerList;
        }


        // Function #1: Button click handler that adds a new traveler and updates UI.
        // This function contains Conditional Block #2 below to validate input before adding.
        private void btnAddTraveler_Click(object? sender, EventArgs e)
        {
            // Guard conditional: ensure the input TextBox exists before using it.
            // Conditional Block #2: avoids NullReferenceException when controls haven't been created.
            if (txtNewPassenger != null)
            {
                string newName = txtNewPassenger.Text.Trim();

                // Conditional Block #3: ensure the user entered a non-empty name.
                // If valid, add to the shared BindingList so any bound UI updates automatically.
                if (!string.IsNullOrWhiteSpace(newName))
                {
                    passengerList.Add(newName);
                    txtNewPassenger.Clear();
                }
                else
                {
                    // Exception/validation #1: user attempted to add an empty name.
                    MessageBox.Show("Traveler name cannot be empty.", "Validation Error");
                }
            }
            else
            {
                // Exception/validation #2: input control unexpectedly not initialized.
                MessageBox.Show("Input box not initialized.", "Error");
            }
        }

        // Function #2: Form load event (currently unused, but kept for lifecycle hooks).
        // You could wire additional initialization here that depends on the form being shown.
        private void ManifestForm_Load(object? sender, EventArgs e)
        {
            // data binding already handles population
        }

        private void InitializeComponent()
        {
            // Basic form setup
            ClientSize = new Size(400, 300);
            Text = "Manifest";

            // lstPassengers
            lstPassengers = new ListBox();
            lstPassengers.Location = new Point(20, 20);
            lstPassengers.Size = new Size(240, 200);
            lstPassengers.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;

            // txtNewPassenger
            txtNewPassenger = new TextBox();
            txtNewPassenger.Location = new Point(20, 230);
            txtNewPassenger.Size = new Size(160, 23);

            // btnAddTraveler
            btnAddTraveler = new Button();
            btnAddTraveler.Text = "Add Traveler";

            // Button #1 (declaration): btnAddTraveler is the Add action button the user clicks to add a name.
            // Hook the click event to the handler above.
            btnAddTraveler.Location = new Point(190, 228);
            btnAddTraveler.Click += btnAddTraveler_Click;

            // Add controls to the form so they are visible to the user.
            // Button #2 (visual placement): Controls.Add(btnAddTraveler) places the actual button instance on the form.
            Controls.Add(lstPassengers);
            Controls.Add(txtNewPassenger);
            Controls.Add(btnAddTraveler);

            // Loop: iterate through the Controls collection to assign TabIndex sequentially.
            // This small loop improves keyboard navigation order and demonstrates a simple iteration.
            for (int i = 0; i < Controls.Count; i++)
            {
                Controls[i].TabIndex = i;
            }

            // Wire Load event (function #2) to lifecycle
            Load += ManifestForm_Load;
        }
    }
}
