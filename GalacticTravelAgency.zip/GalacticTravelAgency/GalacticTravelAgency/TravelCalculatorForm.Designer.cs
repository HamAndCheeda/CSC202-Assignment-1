﻿using System.Windows.Forms;
using System.Drawing;
using System.Globalization;
using System.ComponentModel; // <-- Add this using directive

namespace GalacticTravelAgency
{
    partial class TravelCalculatorForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private IContainer components = null;

        // UI controls referenced by the form logic
        private TableLayoutPanel layoutPanel;
        private Label lblDistanceLabel;
        private NumericUpDown nudDistance;
        private Label lblPassengersLabel;
        private NumericUpDown nudPassengerCount;
        private Label lblResult;
        private Label lblStatus;
        private Button btnCalculate;
        private Button btnClear;
        private Button btnOpenManifest;
        private ErrorProvider errorProvider;
        private ToolTip toolTip1;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new Container();
            errorProvider = new ErrorProvider(components);
            toolTip1 = new ToolTip(components);
            nudDistance = new NumericUpDown();
            nudPassengerCount = new NumericUpDown();
            layoutPanel = new TableLayoutPanel();
            lblDistanceLabel = new Label();
            lblPassengersLabel = new Label();
            lblResult = new Label();
            lblStatus = new Label();
            btnCalculate = new Button();
            btnClear = new Button();
            btnOpenManifest = new Button();
            buttonPanel = new FlowLayoutPanel();
            ((ISupportInitialize)errorProvider).BeginInit();
            ((ISupportInitialize)nudDistance).BeginInit();
            ((ISupportInitialize)nudPassengerCount).BeginInit();
            layoutPanel.SuspendLayout();
            buttonPanel.SuspendLayout();
            SuspendLayout();
            // 
            // errorProvider
            // 
            errorProvider.BlinkStyle = ErrorBlinkStyle.NeverBlink;
            errorProvider.ContainerControl = this;
            // 
            // nudDistance
            // 
            nudDistance.DecimalPlaces = 2;
            nudDistance.Increment = new decimal(new int[] { 1, 0, 0, 65536 });
            nudDistance.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
            nudDistance.Name = "nudDistance";
            nudDistance.TabIndex = 1;
            toolTip1.SetToolTip(nudDistance, "Enter distance in light years");
            nudDistance.ValueChanged += Input_ValueChanged;
            nudDistance.Validating += nudDistance_Validating;
            // 
            // nudPassengerCount
            // 
            nudPassengerCount.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudPassengerCount.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            nudPassengerCount.Name = "nudPassengerCount";
            nudPassengerCount.TabIndex = 3;
            toolTip1.SetToolTip(nudPassengerCount, "Number of passengers (min 1)");
            nudPassengerCount.Value = new decimal(new int[] { 1, 0, 0, 0 });
            nudPassengerCount.ValueChanged += Input_ValueChanged;
            nudPassengerCount.Validating += nudPassengerCount_Validating;
            // 
            // layoutPanel
            // 
            layoutPanel.AutoSize = false;
            layoutPanel.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            layoutPanel.ColumnCount = 2;
            layoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            layoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60F));
            layoutPanel.Controls.Add(lblDistanceLabel, 0, 0);
            layoutPanel.Controls.Add(nudDistance, 1, 0);
            layoutPanel.Controls.Add(lblPassengersLabel, 0, 1);
            layoutPanel.Controls.Add(nudPassengerCount, 1, 1);
            layoutPanel.Controls.Add(lblResult, 0, 2);
            layoutPanel.Controls.Add(lblStatus, 0, 3);
            // Fill remaining client area so controls won't be clipped.
            layoutPanel.Dock = DockStyle.Fill;
            layoutPanel.Location = new Point(0, 0);
            layoutPanel.Name = "layoutPanel";
            layoutPanel.Padding = new Padding(12);
            layoutPanel.RowCount = 4;
            layoutPanel.RowStyles.Clear();
            layoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layoutPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layoutPanel.TabIndex = 1;
            // 
            // lblDistanceLabel
            // 
            lblDistanceLabel.AutoSize = true;
            lblDistanceLabel.Name = "lblDistanceLabel";
            lblDistanceLabel.TabIndex = 0;
            lblDistanceLabel.Text = "Distance (light years):";
            lblDistanceLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblPassengersLabel
            // 
            lblPassengersLabel.AutoSize = true;
            lblPassengersLabel.Name = "lblPassengersLabel";
            lblPassengersLabel.TabIndex = 2;
            lblPassengersLabel.Text = "Passengers:";
            lblPassengersLabel.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            layoutPanel.SetColumnSpan(lblResult, 2);
            lblResult.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblResult.Name = "lblResult";
            lblResult.TabIndex = 4;
            lblResult.Text = "Total: $0.00";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            layoutPanel.SetColumnSpan(lblStatus, 2);
            lblStatus.Name = "lblStatus";
            lblStatus.TabIndex = 5;
            // 
            // btnCalculate
            // 
            btnCalculate.AutoSize = true;
            btnCalculate.Name = "btnCalculate";
            btnCalculate.TabIndex = 0;
            btnCalculate.Text = "&Calculate";
            btnCalculate.Click += BtnCalculate_Click;
            // 
            // btnClear
            // 
            btnClear.AutoSize = true;
            btnClear.Name = "btnClear";
            btnClear.TabIndex = 1;
            btnClear.Text = "&Clear";
            btnClear.Click += BtnClear_Click;
            // 
            // btnOpenManifest
            // 
            btnOpenManifest.AutoSize = true;
            btnOpenManifest.Enabled = false;
            btnOpenManifest.Name = "btnOpenManifest";
            btnOpenManifest.TabIndex = 2;
            btnOpenManifest.Text = "Open Manifest";
            btnOpenManifest.Click += BtnOpenManifest_Click;
            // 
            // buttonPanel
            // 
            buttonPanel.AutoSize = false;
            buttonPanel.FlowDirection = FlowDirection.LeftToRight;
            buttonPanel.Controls.Add(btnCalculate);
            buttonPanel.Controls.Add(btnClear);
            buttonPanel.Controls.Add(btnOpenManifest);
            buttonPanel.Dock = DockStyle.Bottom;
            buttonPanel.Name = "buttonPanel";
            buttonPanel.Padding = new Padding(10, 8, 10, 8);
            buttonPanel.Height = 56;
            buttonPanel.TabIndex = 0;
            // 
            // TravelCalculatorForm
            // 
            AcceptButton = btnCalculate;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            CancelButton = btnClear;
            // Give more initial client area to avoid clipping of runtime-added status strip and preview.
            ClientSize = new Size(640, 380);
            Controls.Clear();
            // Add layout first so it occupies the main area, then button panel (docked bottom).
            Controls.Add(layoutPanel);
            Controls.Add(buttonPanel);
            Font = new Font("Segoe UI", 9F);
            MinimumSize = new Size(520, 320);
            Name = "TravelCalculatorForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Travel Calculator";
            ((ISupportInitialize)errorProvider).EndInit();
            ((ISupportInitialize)nudDistance).EndInit();
            ((ISupportInitialize)nudPassengerCount).EndInit();
            layoutPanel.ResumeLayout(false);
            layoutPanel.PerformLayout();
            buttonPanel.ResumeLayout(false);
            buttonPanel.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private FlowLayoutPanel buttonPanel;
    }
}
