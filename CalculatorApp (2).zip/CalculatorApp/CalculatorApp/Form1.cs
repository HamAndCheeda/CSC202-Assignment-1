namespace CalculatorApp
{
    public partial class Form1 : Form
    {
        // --- Global Variables ---
        string first = "";      // Stores the first number input as a string
        string second = "";     // Stores the second number input as a string after an operator is selected
        char function;          // Holds the operator (+, -, *, /) selected by the user
        double result = 0.0;    // Stores the result of the calculation
        string userInput = "";  // Accumulates the current number input by the user as a string

        public Form1()
        {
            InitializeComponent();
        }
        #region Number Button Events
        /* * All number click events follow the same logic:
         * 1. Clear the display (optional logic on UX preference)
         * 2. Append the corresponding number to userInput
         * 3. Update the display with the new userInput
         */
        private void num1_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "1";
            calculatorDisplay.Text += userInput;
        }
        // ... (Methods num2 through num0 follow the same pattern)
        #endregion

        private void num2_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "2";  
            calculatorDisplay.Text += userInput;
        }

        private void num3_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "3";
            calculatorDisplay.Text += userInput;
        }

        private void num4_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "4";
            calculatorDisplay.Text += userInput;
        }

        private void num5_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "5";
            calculatorDisplay.Text += userInput;
        }

        private void num6_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "6";
            calculatorDisplay.Text += userInput;
        }

        private void num7_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "7";
            calculatorDisplay.Text += userInput;
        }

        private void num8_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "8";
            calculatorDisplay.Text += userInput;
        }

        private void num9_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "9";
            calculatorDisplay.Text += userInput;
        }

        private void zerobutton_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text = "";
            userInput += "0";
            calculatorDisplay.Text += userInput;
        }

        private void decimalButton_Click(object sender, EventArgs e)
        {
            calculatorDisplay.Text += ".";
        }

        #region Operator Logic
        /*
         * When an operator button is clicked:
         * 1. Store the chosen operator in 'function' variable.
         * 2. Move the current 'userInput' to 'first' operand.
         * 3. Reset 'userInput' for the next number input.
         */
        private void divideButton_Click(object sender, EventArgs e)
        {
            function = '/';
            first = userInput;
            userInput = "";
        }

        private void multiplyButton_Click(object sender, EventArgs e)
        {
            function = '*';
            first = userInput;
            userInput = "";
        }

        private void plusButton_Click(object sender, EventArgs e)
        {
            function = '+';
            first = userInput;
            userInput = "";
        }

        private void minusButton_Click(object sender, EventArgs e)
        {
            function = '-';
            first = userInput;
            userInput = "";
        }
        #endregion

        /// <summary>
        /// Handles the Click event of the equal button to perform the selected arithmetic operation and display the
        /// result.
        /// </summary>
        /// <remarks>If division by zero is attempted, an error message is displayed instead of a
        /// result.</remarks>
        /// <param name="sender">The source of the event, typically the equal button control.</param>
        /// <param name="e">An EventArgs object that contains the event data.</param>
        private void equalButton_Click(object sender, EventArgs e)
        {
            second = userInput; // Capture the current input as the second operand
            double num1, num2;

            // Convert the string operands to double for calculation
            // Note: Error handling for invalid input is not implemented here
            num1 = Convert.ToDouble(first);
            num2 = Convert.ToDouble(second);

            // Calculation Switch/Logic
            if (function == '+')
            {
                result = num1 + num2;
                calculatorDisplay.Text = result.ToString();
            }
            else if (function == '-')
            {
                result = num1 - num2;
                calculatorDisplay.Text = result.ToString();
            }
            else if (function == '*')
            {
                result = num1 * num2;
                calculatorDisplay.Text = result.ToString();
            }
            else if (function == '/')
            {
                // Check for division by zero to prevent runtime errors
                if (num2 != 0)
                {
                    result = num1 / num2;
                    calculatorDisplay.Text = result.ToString();
                }
                else
                {
                    calculatorDisplay.Text = "Error: Div by 0";
                }
            }
        }

        /// <summary>
        /// Resets the calculator state and display when the clear button is clicked.
        /// </summary>
        private void clearButton_Click(object sender, EventArgs e)
        {
            first = "";
            second = "";
            userInput = "";
            result = 0.0;
            calculatorDisplay.Text = "0";
        }
    }
}
