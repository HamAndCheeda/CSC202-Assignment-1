﻿namespace GUI_Assert_Demo
{
    partial class GUI_Assert
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // Controls referenced from GUI_Assert.cs
        private System.Windows.Forms.TextBox txtInput1;
        private System.Windows.Forms.TextBox txtInput2;
        private System.Windows.Forms.Button btnRunTests;
        private System.Windows.Forms.Label lblHex;
        private System.Windows.Forms.Label lblTemp;
        private System.Windows.Forms.ListBox lstResults;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtInput1 = new System.Windows.Forms.TextBox();
            this.txtInput2 = new System.Windows.Forms.TextBox();
            this.btnRunTests = new System.Windows.Forms.Button();
            this.lblHex = new System.Windows.Forms.Label();
            this.lblTemp = new System.Windows.Forms.Label();
            this.lstResults = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // txtInput1
            // 
            this.txtInput1.Location = new System.Drawing.Point(12, 12);
            this.txtInput1.Name = "txtInput1";
            this.txtInput1.Size = new System.Drawing.Size(200, 23);
            this.txtInput1.TabIndex = 0;
            // 
            // lblHex
            // 
            this.lblHex.AutoSize = true;
            this.lblHex.Location = new System.Drawing.Point(220, 15);
            this.lblHex.Name = "lblHex";
            this.lblHex.Size = new System.Drawing.Size(120, 15);
            this.lblHex.TabIndex = 3;
            this.lblHex.Text = "Hex color (e.g. #FF5733):";
            // 
            // txtInput2
            // 
            this.txtInput2.Location = new System.Drawing.Point(12, 50);
            this.txtInput2.Name = "txtInput2";
            this.txtInput2.Size = new System.Drawing.Size(200, 23);
            this.txtInput2.TabIndex = 1;
            // 
            // lblTemp
            // 
            this.lblTemp.AutoSize = true;
            this.lblTemp.Location = new System.Drawing.Point(220, 53);
            this.lblTemp.Name = "lblTemp";
            this.lblTemp.Size = new System.Drawing.Size(140, 15);
            this.lblTemp.TabIndex = 4;
            this.lblTemp.Text = "Temperature (°C, 20 - 80):";
            // 
            // btnRunTests
            // 
            this.btnRunTests.Location = new System.Drawing.Point(12, 90);
            this.btnRunTests.Name = "btnRunTests";
            this.btnRunTests.Size = new System.Drawing.Size(100, 30);
            this.btnRunTests.TabIndex = 2;
            this.btnRunTests.Text = "Run Tests";
            this.btnRunTests.UseVisualStyleBackColor = true;
            this.btnRunTests.Click += new System.EventHandler(this.btnRunTests_Click);
            // 
            // lstResults
            // 
            this.lstResults.FormattingEnabled = true;
            this.lstResults.ItemHeight = 15;
            this.lstResults.Location = new System.Drawing.Point(12, 130);
            this.lstResults.Name = "lstResults";
            this.lstResults.Size = new System.Drawing.Size(400, 94);
            this.lstResults.TabIndex = 5;
            // 
            // GUI_Assert
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lstResults);
            this.Controls.Add(this.btnRunTests);
            this.Controls.Add(this.txtInput2);
            this.Controls.Add(this.lblTemp);
            this.Controls.Add(this.txtInput1);
            this.Controls.Add(this.lblHex);
            this.Name = "GUI_Assert";
            this.Text = "GUI Assert Demo";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
