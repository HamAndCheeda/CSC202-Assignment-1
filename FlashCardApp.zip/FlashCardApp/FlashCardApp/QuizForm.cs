using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace FlashcardApp
{
    // QuizForm: a simple modal dialog that iterates over a provided deck
    // and presents each card to the user for answering.
    public partial class QuizForm : Form
    {
        // In-memory reference to the quiz deck passed from MainForm.
        private List<Flashcard> _quizDeck;

        // Index of the current card being shown.
        private int _currentIndex = 0;

        // Constructor receives the deck to quiz on.
        public QuizForm(List<Flashcard> cards)
        {
            // Standard WinForms initialization (Designer-generated controls).
            InitializeComponent();

            // Keep a reference to the deck. We do not clone it so any changes
            // (marking learned, etc.) will be visible to the caller.
            _quizDeck = cards;

            // Display the first appropriate card.
            DisplayCard();
        }

        // DisplayCard: finds the next unlearned card starting from _currentIndex
        // and updates the UI (question label, answer box). If no unlearned cards
        // remain the quiz completes and the form closes.
        private void DisplayCard()
        {
            bool foundCard = false;

            // Loop through the deck to find the next card that isn't marked learned.
            for (int i = _currentIndex; i < _quizDeck.Count; i++)
            {
                // If the card is not learned present it to the user.
                if (!_quizDeck[i].IsLearned)
                {
                    lblQuestion.Text = _quizDeck[i].Question; // show question
                    txtAnswer.Clear(); // clear previous answer
                    _currentIndex = i;
                    foundCard = true;
                    break; // stop searching
                }
            }

            // If nothing was found, the study session is complete.
            if (!foundCard)
            {
                MessageBox.Show("Study session complete!");
                this.Close();
            }
        }

        // btnSubmit_Click: evaluate the user's answer and provide feedback.
        // Marks cards as learned on correct answers and advances to the next card.
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // Simple normalized comparison (trim + lower-case).
            string userAnswer = txtAnswer.Text.Trim().ToLower();

            // Defensive check in case indexes are out of range.
            if (_currentIndex < 0 || _currentIndex >= _quizDeck.Count)
            {
                MessageBox.Show("No card is currently selected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string correctAnswer = _quizDeck[_currentIndex].Answer?.ToLower() ?? string.Empty;

            // Grading decision: correct vs incorrect.
            if (userAnswer == correctAnswer)
            {
                lblFeedback.Text = "Correct!";
                _quizDeck[_currentIndex].IsLearned = true; // mark learned for future sessions
            }
            else
            {
                lblFeedback.Text = $"Wrong! Correct answer: {correctAnswer}";
            }

            // Advance to the next card and show it.
            _currentIndex++;
            DisplayCard();
        }
    }
}
