using System;
using System.Collections.Generic; // Requirement 8: List
using System.IO;
using System.Windows.Forms;
using System.Text.Json; // Using JSON for Requirement 9

namespace FlashcardApp
{
    public partial class MainForm : Form
    {
        // -------------------------
        // Fields / state
        // -------------------------
        // The in-memory collection of flashcards. This is the "deck" the user works with.
        private List<Flashcard> _deck = new List<Flashcard>();

        // Dedicated folder where decks are stored. We keep all deck JSON files here.
        private string _decksDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "decks");
        // The file path where the deck is saved and loaded from. Defaults to "decks/deck.json".
        private string _filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "decks", "deck.json");

        // Support for a simple "undo" of a single remove operation.
        // When the user removes a card we keep it here so they can undo the removal.
        private Flashcard _lastRemovedCard = null;
        private int _lastRemovedIndex = -1;

        // -------------------------
        // Constructor
        // -------------------------
        public MainForm()
        {
            // Standard WinForms initialization (created by the Designer).
            InitializeComponent();

            // Ensure the decks folder exists before we do any file work.
            try
            {
                Directory.CreateDirectory(_decksDir);
            }
            catch { /* ignore create errors, they'll surface on IO ops */ }

            // Ensure UI reflects initial empty deck state.
            UpdateDeckList();
            UpdateStatusStripFile();
            // Populate the saved-decks list so users can open any existing deck file.
            RefreshSavedDeckList();
        }

        // -------------------------
        // Event handlers (wired in the Designer)
        // -------------------------

        // Click handler for the "Load Deck" button.
        // Loads the JSON file from disk and deserializes it into _deck.
        private void btnLoadDeck_Click(object sender, EventArgs e)
        {
            LoadDeckFromFile();
        }

        // Click handler for the "Start Quiz" button.
        // If the deck has cards, opens QuizForm (modal) so the user can study.
        private void btnStartQuiz_Click(object sender, EventArgs e)
        {
            // Only start the quiz when we have at least one card.
            if (_deck.Count > 0)
            {
                // Create the quiz form and pass the deck by reference so progress can be saved back.
                QuizForm quiz = new QuizForm(_deck);
                quiz.ShowDialog();

                // After the quiz completes (dialog closed) we save the deck to persist any progress.
                SaveDeck();
            }
            else
            {
                // Inform the user that they need cards before quizzing.
                MessageBox.Show("Please load or add cards first!");
            }
        }

        // -------------------------
        // Persistence: Load / Save
        // -------------------------

        // Loads the deck from the JSON file at _filePath. Exceptions are caught and shown to the user.
        private void LoadDeckFromFile()
        {
            try
            {
                // Only attempt to read if the file exists to avoid exceptions.
                if (File.Exists(_filePath))
                {
                    // Read the entire file into a string.
                    string jsonString = File.ReadAllText(_filePath);

                    // Deserialize JSON to a List<Flashcard>. If the JSON is invalid this will throw.
                    _deck = JsonSerializer.Deserialize<List<Flashcard>>(jsonString);

                    // Refresh the UI to show the loaded cards and update status bar.
                    UpdateDeckList();
                    UpdateStatusStripFile();
                }
            }
            catch (Exception ex)
            {
                // Show a friendly error if anything went wrong (file locked, invalid JSON, etc.).
                MessageBox.Show("Error loading file: " + ex.Message);
            }
        }

        // Saves the current _deck to the JSON file at _filePath. Only IO exceptions are expected here.
        private void SaveDeck()
        {
            try
            {
                // Convert the deck into a JSON string.
                string json = JsonSerializer.Serialize(_deck);

                // Overwrite the file with the current deck JSON.
                File.WriteAllText(_filePath, json);

                // Update the status strip so the user knows when the deck was last saved.
                UpdateStatusStripSaved();
                // Refresh list of saved decks so the UI reflects any new files.
                RefreshSavedDeckList();
            }
            catch (IOException ioEx)
            {
                // Inform the user about file system errors (disk full, permissions, etc.).
                MessageBox.Show("FileSystem Error: " + ioEx.Message);
            }
        }

        // -------------------------
        // UI helpers
        // -------------------------

        // Update the contents of the list box that shows the deck, and refresh minor status labels.
        private void UpdateDeckList()
        {
            // BeginUpdate/EndUpdate improves performance and prevents flicker while modifying list items.
            lstDeck.BeginUpdate();

            // Remove all existing items and repopulate from the in-memory _deck.
            lstDeck.Items.Clear();
            foreach (var c in _deck)
                lstDeck.Items.Add(c.Front); // show the "Front" (question) text in the list

            lstDeck.EndUpdate();

            // Update the small status label that tells how many cards are loaded.
            lblStatus.Text = $"Loaded {_deck.Count} cards.";
            if (lblCount != null)
                lblCount.Text = $"{_deck.Count} cards";

            // When there are no cards, hide the list and show a helpful placeholder label.
            // This removes the empty white box that appears in the top-left when the deck is empty.
            try
            {
                if (lblEmpty != null)
                {
                    lblEmpty.Visible = (_deck.Count == 0);
                    lstDeck.Visible = (_deck.Count > 0);
                }
            }
            catch { }
        }

        // -------------------------
        // Add / Remove / Edit operations
        // -------------------------

        // Adds a new card to the deck using the values in the Front/Back text boxes.
        // If either field is empty we ignore the request.
        private void btnAddCard_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFront.Text) || string.IsNullOrWhiteSpace(txtBack.Text))
                return; // simple validation: both sides must contain text

            // Create a new Flashcard and append to the in-memory deck.
            _deck.Add(new Flashcard { Front = txtFront.Text.Trim(), Back = txtBack.Text.Trim() });

            // Refresh the UI list, persist the change, and clear the entry fields for convenience.
            UpdateDeckList();
            SaveDeck();
            txtFront.Clear();
            txtBack.Clear();
        }

        // Remove the selected card from the deck and keep it in memory for a possible undo.
        private void btnRemoveCard_Click(object sender, EventArgs e)
        {
            if (lstDeck.SelectedIndex >= 0)
            {
                // Save state for undo: the removed card and its index.
                _lastRemovedIndex = lstDeck.SelectedIndex;
                _lastRemovedCard = _deck[_lastRemovedIndex];

                // Remove from the in-memory deck and persist the change.
                _deck.RemoveAt(_lastRemovedIndex);
                UpdateDeckList();
                SaveDeck();
            }
        }

        // Restore the last removed card if available.
        private void btnUndoRemove_Click(object sender, EventArgs e)
        {
            // If we have a stored removed card we can re-insert it.
            if (_lastRemovedCard != null && _lastRemovedIndex >= 0)
            {
                // Insert at the original index when possible; otherwise append.
                if (_lastRemovedIndex <= _deck.Count)
                    _deck.Insert(_lastRemovedIndex, _lastRemovedCard);
                else
                    _deck.Add(_lastRemovedCard);

                // Clear undo state and persist changes.
                _lastRemovedCard = null;
                _lastRemovedIndex = -1;
                UpdateDeckList();
                SaveDeck();
            }
            else
            {
                // No undo available — inform the user.
                MessageBox.Show("Nothing to undo.", "Undo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // -------------------------
        // Import / Export
        // -------------------------

        // Export current deck to a user-selected JSON file (pretty-printed).
        private void btnExportDeck_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "JSON files|*.json|All files|*.*";
                sfd.InitialDirectory = _decksDir; // default to decks folder
                sfd.FileName = "deck_export.json";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Use indented JSON to make the exported file easier to read.
                        string json = JsonSerializer.Serialize(_deck, new JsonSerializerOptions { WriteIndented = true });
                        File.WriteAllText(sfd.FileName, json);
                        MessageBox.Show("Export successful.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // Refresh saved decks list because export created/updated a file.
                        RefreshSavedDeckList();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Export failed: " + ex.Message, "Export", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Import cards from a JSON file and append them to the current deck.
        private void btnImportDeck_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "JSON files|*.json|All files|*.*";
                ofd.InitialDirectory = _decksDir; // start browsing in decks folder
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string json = File.ReadAllText(ofd.FileName);
                        var imported = JsonSerializer.Deserialize<List<Flashcard>>(json);
                        if (imported != null)
                        {
                            // Append imported cards and persist.
                            _deck.AddRange(imported);
                            UpdateDeckList();
                            SaveDeck();
                            // Refresh saved decks list because import updated the persistent deck file.
                            RefreshSavedDeckList();
                            MessageBox.Show($"Imported {imported.Count} cards.", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    catch (Exception ex)
                    {
                        // Show an error when import fails (invalid JSON, etc.).
                        MessageBox.Show("Import failed: " + ex.Message, "Import", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // -------------------------
        // Status strip helpers
        // -------------------------

        // Refresh the list of saved decks shown in the combo box.
        // Scans the application's current directory for JSON files and lists them.
        private void RefreshSavedDeckList()
        {
            try
            {
                if (cmbSavedDecks == null) return;
                cmbSavedDecks.Items.Clear();

                // Look for JSON files in the dedicated decks folder.
                var files = Directory.GetFiles(_decksDir, "*.json");
                foreach (var f in files)
                {
                    // Use file name only for display.
                    cmbSavedDecks.Items.Add(Path.GetFileName(f));
                }

                if (cmbSavedDecks.Items.Count > 0)
                    cmbSavedDecks.SelectedIndex = 0;
            }
            catch { /* ignore errors scanning the directory */ }
        }


        // Update the left-hand status item with the current file path.
        private void UpdateStatusStripFile()
        {
            try
            {
                if (this.toolStripStatusFile != null)
                    this.toolStripStatusFile.Text = $"File: {_filePath}";
            }
            catch { /* Ignore UI update errors */ }
        }

        // Update the "last saved" status to the current date/time.
        private void UpdateStatusStripSaved()
        {
            try
            {
                if (this.toolStripStatusSaved != null)
                    this.toolStripStatusSaved.Text = $"Last saved: {DateTime.Now}";
            }
            catch { /* Ignore UI update errors */ }
        }

        // Open the selected saved deck from the combo box and load it.
        private void btnOpenDeck_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbSavedDecks == null || cmbSavedDecks.SelectedItem == null)
                {
                    MessageBox.Show("Please select a saved deck to open.", "Open", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string fileName = cmbSavedDecks.SelectedItem.ToString();
                string fullPath = Path.Combine(_decksDir, fileName);

                if (!File.Exists(fullPath))
                {
                    MessageBox.Show("Selected file does not exist.", "Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    RefreshSavedDeckList();
                    return;
                }

                // Set as current file and load it.
                _filePath = fullPath;
                LoadDeckFromFile();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to open deck: " + ex.Message, "Open", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Delete the selected saved deck file from disk. Prompts for confirmation.
        private void btnDeleteDeck_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbSavedDecks == null || cmbSavedDecks.SelectedItem == null)
                {
                    MessageBox.Show("Please select a saved deck to delete.", "Delete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string fileName = cmbSavedDecks.SelectedItem.ToString();
                string fullPath = Path.Combine(_decksDir, fileName);

                var res = MessageBox.Show($"Delete '{fileName}' from disk?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (res == DialogResult.Yes)
                {
                    try
                    {
                        File.Delete(fullPath);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Could not delete file: " + ex.Message, "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // If we deleted the currently open deck, clear the UI and reset to default.
                    if (string.Equals(_filePath, fullPath, StringComparison.OrdinalIgnoreCase))
                    {
                        _deck.Clear();
                        _filePath = "deck.json";
                        UpdateDeckList();
                        UpdateStatusStripFile();
                    }

                    RefreshSavedDeckList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to delete deck: " + ex.Message, "Delete", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // -------------------------
        // Small utility UI handlers
        // -------------------------

        // Save button — provide an explicit save action for the user.
        private void btnSaveDeck_Click(object sender, EventArgs e)
        {
            SaveDeck();
            MessageBox.Show("Deck saved.", "Save", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Save As: let the user choose a filename to save the current deck.
        // This updates the application's current _filePath so subsequent saves
        // will write to the chosen file and the saved-decks list will include it.
        private void btnSaveAs_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "JSON files|*.json|All files|*.*";
                // Suggest the current file name as default
                try { sfd.FileName = Path.GetFileName(_filePath); } catch { sfd.FileName = "deck.json"; }

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        // Update the current file path to the user's choice.
                        _filePath = sfd.FileName;

                        // Persist the deck to the new file.
                        string json = JsonSerializer.Serialize(_deck, new JsonSerializerOptions { WriteIndented = true });
                        File.WriteAllText(_filePath, json);

                        // Update UI to reflect new file and refresh the saved-decks list.
                        UpdateStatusStripFile();
                        UpdateStatusStripSaved();
                        RefreshSavedDeckList();

                        MessageBox.Show("Deck saved.", "Save As", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Save As failed: " + ex.Message, "Save As", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        // Clear button — remove all cards after confirmation.
        private void btnClearDeck_Click(object sender, EventArgs e)
        {
            var res = MessageBox.Show("Are you sure you want to remove all cards?", "Confirm Clear", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == DialogResult.Yes)
            {
                _deck.Clear();
                UpdateDeckList();
                SaveDeck();
            }
        }

        // When the user selects an item in the list show the full Front and Back values in the text boxes.
        private void lstDeck_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstDeck.SelectedIndex >= 0)
            {
                var card = _deck[lstDeck.SelectedIndex];
                txtFront.Text = card.Front;
                txtBack.Text = card.Back;
            }
        }
    }
}
