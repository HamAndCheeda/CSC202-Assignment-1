﻿namespace FlashcardApp
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.btnLoadDeck = new System.Windows.Forms.Button();
            this.btnStartQuiz = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lstDeck = new System.Windows.Forms.ListBox();
            this.txtFront = new System.Windows.Forms.TextBox();
            this.txtBack = new System.Windows.Forms.TextBox();
            this.btnAddCard = new System.Windows.Forms.Button();
            this.btnRemoveCard = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoadDeck
            // 
            this.btnLoadDeck.Location = new System.Drawing.Point(12, 12);
            this.btnLoadDeck.Name = "btnLoadDeck";
            this.btnLoadDeck.Size = new System.Drawing.Size(110, 34);
            this.btnLoadDeck.TabIndex = 0;
            this.btnLoadDeck.Text = "Load Deck";
            this.btnLoadDeck.UseVisualStyleBackColor = true;
            this.btnLoadDeck.Click += new System.EventHandler(this.btnLoadDeck_Click);
            this.btnLoadDeck.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnLoadDeck.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left);
            // 
            // btnStartQuiz
            // 
            this.btnStartQuiz.Location = new System.Drawing.Point(132, 12);
            this.btnStartQuiz.Name = "btnStartQuiz";
            this.btnStartQuiz.Size = new System.Drawing.Size(110, 34);
            this.btnStartQuiz.TabIndex = 1;
            this.btnStartQuiz.Text = "Start Quiz";
            this.btnStartQuiz.UseVisualStyleBackColor = true;
            this.btnStartQuiz.Click += new System.EventHandler(this.btnStartQuiz_Click);
            this.btnStartQuiz.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnStartQuiz.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(12, 56);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 17);
            this.lblStatus.TabIndex = 2;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            // 
            // lstDeck
            // 
            this.lstDeck.FormattingEnabled = true;
            this.lstDeck.ItemHeight = 18;
            this.lstDeck.Location = new System.Drawing.Point(12, 85);
            this.lstDeck.Name = "lstDeck";
            this.lstDeck.Size = new System.Drawing.Size(320, 300);
            this.lstDeck.TabIndex = 3;
            this.lstDeck.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lstDeck.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
            // 
            // lblEmpty
            // 
            this.lblEmpty = new System.Windows.Forms.Label();
            this.lblEmpty.Location = new System.Drawing.Point(12, 85);
            this.lblEmpty.Name = "lblEmpty";
            this.lblEmpty.Size = new System.Drawing.Size(320, 300);
            this.lblEmpty.TabIndex = 20;
            this.lblEmpty.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.lblEmpty.Text = "No cards yet — use the Front and Back fields to add your first card.";
            this.lblEmpty.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblEmpty.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblEmpty.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
            this.lstDeck.SelectedIndexChanged += new System.EventHandler(this.lstDeck_SelectedIndexChanged);
            // 
            // txtFront
            // 
            this.txtFront.Location = new System.Drawing.Point(350, 85);
            this.txtFront.Multiline = true;
            this.txtFront.Name = "txtFront";
            this.txtFront.Size = new System.Drawing.Size(420, 140);
            this.txtFront.TabIndex = 4;
            this.txtFront.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtFront.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right);
            // 
            // txtBack
            // 
            this.txtBack.Location = new System.Drawing.Point(350, 235);
            this.txtBack.Multiline = true;
            this.txtBack.Name = "txtBack";
            this.txtBack.Size = new System.Drawing.Size(420, 150);
            this.txtBack.TabIndex = 5;
            this.txtBack.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBack.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right);
            // 
            // btnAddCard
            // 
            this.btnAddCard.Location = new System.Drawing.Point(350, 395);
            this.btnAddCard.Name = "btnAddCard";
            this.btnAddCard.Size = new System.Drawing.Size(110, 36);
            this.btnAddCard.TabIndex = 6;
            this.btnAddCard.Text = "Add Card";
            this.btnAddCard.UseVisualStyleBackColor = true;
            this.btnAddCard.Click += new System.EventHandler(this.btnAddCard_Click);
            this.btnAddCard.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAddCard.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right | System.Windows.Forms.AnchorStyles.Left);
            // 
            // btnRemoveCard
            // 
            this.btnRemoveCard.Location = new System.Drawing.Point(470, 395);
            this.btnRemoveCard.Name = "btnRemoveCard";
            this.btnRemoveCard.Size = new System.Drawing.Size(110, 36);
            this.btnRemoveCard.TabIndex = 7;
            this.btnRemoveCard.Text = "Remove";
            this.btnRemoveCard.UseVisualStyleBackColor = true;
            this.btnRemoveCard.Click += new System.EventHandler(this.btnRemoveCard_Click);
            this.btnRemoveCard.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRemoveCard.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
            // 
            // btnSaveDeck
            // 
            this.btnSaveDeck = new System.Windows.Forms.Button();
            this.btnImportDeck = new System.Windows.Forms.Button();
            this.btnExportDeck = new System.Windows.Forms.Button();
            this.btnUndoRemove = new System.Windows.Forms.Button();
            this.btnSaveDeck.Location = new System.Drawing.Point(252, 12);
            this.btnSaveDeck.Name = "btnSaveDeck";
            this.btnSaveDeck.Size = new System.Drawing.Size(110, 34);
            this.btnSaveDeck.TabIndex = 8;
            this.btnSaveDeck.Text = "Save Deck";
            this.btnSaveDeck.UseVisualStyleBackColor = true;
            this.btnSaveDeck.Click += new System.EventHandler(this.btnSaveDeck_Click);
            this.btnSaveDeck.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSaveDeck.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left);

            // 
            // btnSaveAs
            // 
            this.btnSaveAs = new System.Windows.Forms.Button();
            this.btnSaveAs.Location = new System.Drawing.Point(372, 12);
            this.btnSaveAs.Name = "btnSaveAs";
            this.btnSaveAs.Size = new System.Drawing.Size(110, 34);
            this.btnSaveAs.TabIndex = 9;
            this.btnSaveAs.Text = "Save As...";
            this.btnSaveAs.UseVisualStyleBackColor = true;
            this.btnSaveAs.Click += new System.EventHandler(this.btnSaveAs_Click);
            this.btnSaveAs.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnSaveAs.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left);

            // 
            // lblSavedDecks
            // 
            this.lblSavedDecks = new System.Windows.Forms.Label();
            this.lblSavedDecks.AutoSize = true;
            this.lblSavedDecks.Location = new System.Drawing.Point(800, 15);
            this.lblSavedDecks.Name = "lblSavedDecks";
            this.lblSavedDecks.Size = new System.Drawing.Size(90, 20);
            this.lblSavedDecks.TabIndex = 16;
            this.lblSavedDecks.Text = "Saved decks:";
            this.lblSavedDecks.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSavedDecks.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);

            // 
            // cmbSavedDecks
            // 
            this.cmbSavedDecks = new System.Windows.Forms.ComboBox();
            this.cmbSavedDecks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSavedDecks.FormattingEnabled = true;
            this.cmbSavedDecks.Location = new System.Drawing.Point(800, 38);
            this.cmbSavedDecks.Name = "cmbSavedDecks";
            this.cmbSavedDecks.Size = new System.Drawing.Size(240, 23);
            this.cmbSavedDecks.TabIndex = 17;
            this.cmbSavedDecks.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);

            // 
            // btnOpenDeck
            // 
            this.btnOpenDeck = new System.Windows.Forms.Button();
            this.btnOpenDeck.Location = new System.Drawing.Point(800, 68);
            this.btnOpenDeck.Name = "btnOpenDeck";
            this.btnOpenDeck.Size = new System.Drawing.Size(110, 30);
            this.btnOpenDeck.TabIndex = 18;
            this.btnOpenDeck.Text = "Open";
            this.btnOpenDeck.UseVisualStyleBackColor = true;
            this.btnOpenDeck.Click += new System.EventHandler(this.btnOpenDeck_Click);
            this.btnOpenDeck.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnOpenDeck.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);

            // 
            // btnDeleteDeck
            // 
            this.btnDeleteDeck = new System.Windows.Forms.Button();
            this.btnDeleteDeck.Location = new System.Drawing.Point(930, 68);
            this.btnDeleteDeck.Name = "btnDeleteDeck";
            this.btnDeleteDeck.Size = new System.Drawing.Size(110, 30);
            this.btnDeleteDeck.TabIndex = 19;
            this.btnDeleteDeck.Text = "Delete";
            this.btnDeleteDeck.UseVisualStyleBackColor = true;
            this.btnDeleteDeck.Click += new System.EventHandler(this.btnDeleteDeck_Click);
            this.btnDeleteDeck.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnDeleteDeck.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
            // 
            // btnClearDeck
            // 
            this.btnClearDeck = new System.Windows.Forms.Button();
            this.btnClearDeck.Location = new System.Drawing.Point(12, 48);
            this.btnClearDeck.Name = "btnClearDeck";
            this.btnClearDeck.Size = new System.Drawing.Size(110, 30);
            this.btnClearDeck.TabIndex = 9;
            this.btnClearDeck.Text = "Clear All";
            this.btnClearDeck.UseVisualStyleBackColor = true;
            this.btnClearDeck.Click += new System.EventHandler(this.btnClearDeck_Click);
            this.btnClearDeck.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnClearDeck.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left);
            // 
            // lblCount
            // 
            this.lblCount = new System.Windows.Forms.Label();
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(132, 52);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(100, 17);
            this.lblCount.TabIndex = 10;
            this.lblCount.Text = "0 cards";
            this.lblCount.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblCount.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left);
            // 
            // txtInstructions
            // 
            this.txtInstructions = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusFile = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusSaved = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.txtInstructions.Location = new System.Drawing.Point(12, 460);
            this.txtInstructions.Multiline = true;
            this.txtInstructions.Name = "txtInstructions";
            this.txtInstructions.ReadOnly = true;
            this.txtInstructions.Size = new System.Drawing.Size(1060, 120);
            this.txtInstructions.TabIndex = 11;
            this.txtInstructions.Text = "Instructions:\r\n- Use the text boxes on the right to create a new card (Front/Back).\r\n- Click 'Add Card' to add it to the deck.\r\n- Select a card in the list to edit or remove it.\r\n- Click 'Start Quiz' to begin reviewing.\r\n- Use 'Save Deck' to persist immediately, or decks are saved when you finish a quiz.";
            this.txtInstructions.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtInstructions.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInstructions.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 620);
            this.MinimumSize = new System.Drawing.Size(980, 560);
            this.Controls.Add(this.txtInstructions);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.btnClearDeck);
            this.Controls.Add(this.btnSaveDeck);
            this.Controls.Add(this.btnSaveAs);
            this.Controls.Add(this.btnImportDeck);
            this.Controls.Add(this.btnExportDeck);
            this.Controls.Add(this.btnRemoveCard);
            this.Controls.Add(this.btnUndoRemove);
            this.Controls.Add(this.btnAddCard);
            this.Controls.Add(this.txtBack);
            this.Controls.Add(this.txtFront);
            this.Controls.Add(this.lstDeck);
            this.Controls.Add(this.lblEmpty);
            // saved decks controls
            this.Controls.Add(this.lblSavedDecks);
            this.Controls.Add(this.cmbSavedDecks);
            this.Controls.Add(this.btnOpenDeck);
            this.Controls.Add(this.btnDeleteDeck);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.btnStartQuiz);
            this.Controls.Add(this.btnLoadDeck);
            this.Controls.Add(this.statusStrip1);
            this.Name = "MainForm";
            this.Text = "Flashcards";
            this.ResumeLayout(false);
            this.PerformLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusFile,
            this.toolStripStatusSaved});
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 22);
            this.statusStrip1.TabIndex = 15;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusFile
            // 
            this.toolStripStatusFile.Name = "toolStripStatusFile";
            this.toolStripStatusFile.Size = new System.Drawing.Size(100, 17);
            this.toolStripStatusFile.Text = "File: deck.json";
            // 
            // toolStripStatusSaved
            // 
            this.toolStripStatusSaved.Name = "toolStripStatusSaved";
            this.toolStripStatusSaved.Size = new System.Drawing.Size(80, 17);
            this.toolStripStatusSaved.Text = "Last saved: -";
            // 
            // toolTip1
            // 
            this.toolTip1.SetToolTip(this.btnAddCard, "Add a new card using the Front and Back fields");
            this.toolTip1.SetToolTip(this.btnRemoveCard, "Remove the selected card");
            this.toolTip1.SetToolTip(this.btnUndoRemove, "Undo the last removal");
            this.toolTip1.SetToolTip(this.btnSaveDeck, "Save deck to disk immediately");
            this.toolTip1.SetToolTip(this.btnClearDeck, "Remove all cards from the deck");
            this.toolTip1.SetToolTip(this.btnStartQuiz, "Start the quiz with current deck");
            this.toolTip1.SetToolTip(this.lstDeck, "List of cards (select to view or edit)");
            this.toolTip1.SetToolTip(this.txtFront, "Card front (question)");
            this.toolTip1.SetToolTip(this.txtBack, "Card back (answer)");
            this.toolTip1.SetToolTip(this.btnExportDeck, "Export deck to a JSON file");
            this.toolTip1.SetToolTip(this.btnImportDeck, "Import cards from a JSON file (appends)");
        }

        private System.Windows.Forms.Button btnLoadDeck;
        private System.Windows.Forms.Button btnStartQuiz;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ListBox lstDeck;
        private System.Windows.Forms.Label lblEmpty;
        private System.Windows.Forms.TextBox txtFront;
        private System.Windows.Forms.TextBox txtBack;
        private System.Windows.Forms.Button btnAddCard;
        private System.Windows.Forms.Button btnRemoveCard;
        private System.Windows.Forms.Button btnSaveDeck;
        private System.Windows.Forms.Button btnSaveAs;
        private System.Windows.Forms.Button btnClearDeck;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.TextBox txtInstructions;
        private System.Windows.Forms.Button btnImportDeck;
        private System.Windows.Forms.Button btnExportDeck;
        private System.Windows.Forms.Button btnUndoRemove;
        private System.Windows.Forms.Label lblSavedDecks;
        private System.Windows.Forms.ComboBox cmbSavedDecks;
        private System.Windows.Forms.Button btnOpenDeck;
        private System.Windows.Forms.Button btnDeleteDeck;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusFile;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusSaved;
        private System.Windows.Forms.ToolTip toolTip1;

        #endregion
    }
}
