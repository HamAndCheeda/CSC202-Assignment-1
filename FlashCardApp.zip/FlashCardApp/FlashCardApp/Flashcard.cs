using System;

namespace FlashcardApp
{
    // Requirement 11: Best naming practices (PascalCase for classes)
    public class Flashcard
    {
        // Requirement 2: Variables of different types (string, int, bool)
        public string Question { get; set; }
        public string Answer { get; set; }
        // Compatibility convenience properties used by MainForm (Front/Back)
        public string Front { get => Question; set => Question = value; }
        public string Back { get => Answer; set => Answer = value; }
        public int DifficultyLevel { get; set; } // 1-5 scale
        public bool IsLearned { get; set; }
        public DateTime LastReviewed { get; set; }

        // Parameterless constructor required for JSON deserialization
        public Flashcard()
        {
            DifficultyLevel = 1;
            IsLearned = false;
            LastReviewed = DateTime.Now;
        }

        public Flashcard(string q, string a) : this()
        {
            Question = q;
            Answer = a;
        }
    }
}