﻿namespace FlashcardApp
{
    partial class QuizForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support. The Designer generates
        /// the code below to create controls used by the QuizForm.
        /// You can read this to see how the UI is constructed, but avoid
        /// manual edits unless necessary — prefer the Visual Studio Designer.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            this.lblQuestion = new System.Windows.Forms.Label();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblQuestion
            // 
            // Make question label multi-line and allow it to expand horizontally with the form.
            this.lblQuestion.AutoSize = false;
            this.lblQuestion.Location = new System.Drawing.Point(12, 12);
            this.lblQuestion.Name = "lblQuestion";
            this.lblQuestion.Size = new System.Drawing.Size(560, 80);
            this.lblQuestion.TabIndex = 0;
            this.lblQuestion.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblQuestion.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right);
            this.lblQuestion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lblQuestion.Text = "";
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(12, 100);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(480, 29);
            this.txtAnswer.TabIndex = 1;
            this.txtAnswer.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtAnswer.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(500, 98);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(90, 32);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            this.btnSubmit.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
            this.AcceptButton = this.btnSubmit;
            // 
            // lblFeedback
            // 
            this.lblFeedback.AutoSize = false;
            this.lblFeedback.Location = new System.Drawing.Point(12, 140);
            this.lblFeedback.Name = "lblFeedback";
            this.lblFeedback.Size = new System.Drawing.Size(580, 60);
            this.lblFeedback.TabIndex = 3;
            this.lblFeedback.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblFeedback.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right);
            this.lblFeedback.Text = "";
            // 
            // QuizForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(610, 220);
            this.Controls.Add(this.lblFeedback);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.lblQuestion);
            this.MinimumSize = new System.Drawing.Size(520, 260);
            this.Name = "QuizForm";
            this.Text = "Quiz";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // Designer-created controls used by the QuizForm UI.
        // lblQuestion: displays the question (front) text of the current flashcard.
        private System.Windows.Forms.Label lblQuestion;
        // txtAnswer: input field where the user types their answer.
        private System.Windows.Forms.TextBox txtAnswer;
        // btnSubmit: button the user clicks to submit their answer for grading.
        private System.Windows.Forms.Button btnSubmit;
        // lblFeedback: shows immediate feedback (Correct/Wrong) after submission.
        private System.Windows.Forms.Label lblFeedback;

        #endregion
    }
}
