// Teacher subclass that extends Person and implements IIdentifiable
using System;

namespace Assignment_3._1.Models
{
    // Teacher represents a person who teaches subjects at an institution.
    public class Teacher : Person, IIdentifiable
    {
        // Encapsulated fields specific to Teacher
        private string _employeeId = string.Empty;  // Employee ID
        private string _department = string.Empty;  // Department name
        private decimal _salary;                    // Annual salary

        // Property for EmployeeId with validation
        public string EmployeeId
        {
            get => _employeeId;
            set => _employeeId = value ?? string.Empty;
        }

        // Property for Department with validation
        public string Department
        {
            get => _department;
            set => _department = value ?? string.Empty;
        }

        // Property for Salary with non-negative rule
        public decimal Salary
        {
            get => _salary;
            set => _salary = (value < 0m) ? 0m : value;
        }

        // Default ctor
        public Teacher() { }

        // Convenience ctor
        public Teacher(string firstName, string lastName, int age, string employeeId, string department, decimal salary)
            : base(firstName, lastName, age)
        {
            EmployeeId = employeeId;
            Department = department;
            Salary = salary;
        }

        // Implement Identify from IIdentifiable
        public string Identify()
        {
            return $"Teacher: {EmployeeId} - {FirstName} {LastName}";
        }

        // Display all attributes including base attributes
        public override string Display()
        {
            return $"{base.Display()}, EmployeeId: {EmployeeId}, Department: {Department}, Salary: {Salary:C}";
        }

        // Display selected number of attributes. Define: 1 -> name+empid, 2 -> name+empid+department
        public override string Display(int attributeCount)
        {
            if (attributeCount <= 1)
            {
                return $"{FirstName} {LastName} (EmpID: {EmployeeId})";
            }
            if (attributeCount == 2)
            {
                return $"{FirstName} {LastName} (EmpID: {EmployeeId}), Dept: {Department}";
            }
            return Display();
        }
    }
}
