// Student subclass that extends Person and implements IIdentifiable
using System;

namespace Assignment_3._1.Models
{
    // Student represents a person who studies at an institution.
    public class Student : Person, IIdentifiable
    {
        // Encapsulated fields specific to Student
        private string _studentId = string.Empty;   // Student ID string
        private string _major = string.Empty;       // Major field of study
        private double _gpa;                        // Grade Point Average

        // Property for StudentId with validation
        public string StudentId
        {
            get => _studentId;
            set => _studentId = value ?? string.Empty;
        }

        // Property for Major with validation
        public string Major
        {
            get => _major;
            set => _major = value ?? string.Empty;
        }

        // Property for GPA with rule: between 0.0 and 4.0
        public double GPA
        {
            get => _gpa;
            set => _gpa = (value < 0.0) ? 0.0 : (value > 4.0 ? 4.0 : value);
        }

        // Default ctor
        public Student() { }

        // Convenience ctor to initialize all properties including inherited ones
        public Student(string firstName, string lastName, int age, string studentId, string major, double gpa)
            : base(firstName, lastName, age)
        {
            StudentId = studentId;
            Major = major;
            GPA = gpa;
        }

        // Implement Identify from IIdentifiable
        public string Identify()
        {
            return $"Student: {StudentId} - {FirstName} {LastName}";
        }

        // Display all attributes including base attributes
        public override string Display()
        {
            return $"{base.Display()}, StudentId: {StudentId}, Major: {Major}, GPA: {GPA:F2}";
        }

        // Display selected number of attributes. Define: 1 -> name+id, 2 -> name+id+major
        public override string Display(int attributeCount)
        {
            if (attributeCount <= 1)
            {
                return $"{FirstName} {LastName} (ID: {StudentId})";
            }
            if (attributeCount == 2)
            {
                return $"{FirstName} {LastName} (ID: {StudentId}), Major: {Major}";
            }
            return Display();
        }
    }
}
