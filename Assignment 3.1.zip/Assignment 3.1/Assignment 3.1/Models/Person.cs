// Person base class with encapsulation and display methods
using System;

namespace Assignment_3._1.Models
{
    // Base class representing a person with common attributes.
    public class Person
    {
        // Encapsulated fields with private setters where appropriate.
        private string _firstName = string.Empty; // First name of person
        private string _lastName = string.Empty;  // Last name of person
        private int _age;                          // Age in years

        // Public property for FirstName with validation in setter.
        public string FirstName
        {
            get => _firstName;
            set => _firstName = value ?? string.Empty; // Ensure not null
        }

        // Public property for LastName with validation in setter.
        public string LastName
        {
            get => _lastName;
            set => _lastName = value ?? string.Empty;
        }

        // Public property for Age with rule: must be non-negative and reasonable.
        public int Age
        {
            get => _age;
            set => _age = (value < 0) ? 0 : (value > 150 ? 150 : value); // clamp
        }

        // Default ctor
        public Person() { }

        // Convenience ctor
        public Person(string firstName, string lastName, int age)
        {
            FirstName = firstName;
            LastName = lastName;
            Age = age;
        }

        // Display all attributes of this person.
        public virtual string Display()
        {
            return $"FirstName: {FirstName}, LastName: {LastName}, Age: {Age}";
        }

        // Display limited number of attributes. For Person: 1 shows names, 2 shows names+age.
        public virtual string Display(int attributeCount)
        {
            if (attributeCount <= 1)
            {
                return $"FirstName: {FirstName} {LastName}";
            }
            // default to 2 or more
            return Display();
        }
    }
}
