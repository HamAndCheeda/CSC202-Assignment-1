// Interface requiring an Identify method
namespace Assignment_3._1.Models
{
    // Small interface to require an identifying method on subclasses.
    public interface IIdentifiable
    {
        // Implementations should return a short identifier string for the object.
        string Identify();
    }
}
