// Main Windows Form UI for creating and displaying Student and Teacher objects
using System;
using System.Collections.Generic;
using System.Linq;
using System.Drawing;
using System.Windows.Forms;
using Assignment_3._1.Models;

namespace Assignment_3._1
{
    public partial class PersonCreator : Form
    {
        // Collections to hold created objects for display and demo
        private readonly List<Person> _createdPeople = new();

        public PersonCreator()
        {
            InitializeComponent();
        }

        // Initialize UI components and layout
        private void InitializeComponent()
        {
            // Create controls. Keep layout simple and accessible.
            // Improve readability: use larger system font and enable autoscaling.
            this.Text = "Person Creator - Assignment 3.1";
            this.AutoScaleMode = AutoScaleMode.Font;
            this.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new Size(800, 500);
            this.Width = 900;
            this.Height = 600;

            // Create main responsive layout panel
            var tlpMain = new TableLayoutPanel()
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                AutoSize = false,
            };
            tlpMain.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            tlpMain.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            // Input area uses a nested TableLayoutPanel for responsive columns
            var tlpInputs = new TableLayoutPanel()
            {
                Dock = DockStyle.Top,
                ColumnCount = 3,
                AutoSize = true,
                Padding = new Padding(8),
            };
            tlpInputs.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
            tlpInputs.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
            tlpInputs.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));

            // Left column: common person fields and type
            var pnlLeft = new FlowLayoutPanel() { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
            var lblFirstName = new Label() { AutoSize = true, Text = "First Name:" };
            var txtFirstName = new TextBox() { Width = 240, Name = "txtFirstName" };
            var lblLastName = new Label() { AutoSize = true, Text = "Last Name:" };
            var txtLastName = new TextBox() { Width = 240, Name = "txtLastName" };
            var lblAge = new Label() { AutoSize = true, Text = "Age:" };
            var txtAge = new TextBox() { Width = 100, Name = "txtAge" };

            var grpType = new GroupBox() { Text = "Type", AutoSize = true };
            var pnlType = new FlowLayoutPanel() { Dock = DockStyle.Fill, AutoSize = true };
            var rdoStudent = new RadioButton() { Text = "Student", Name = "rdoStudent", Checked = true, AutoSize = true };
            var rdoTeacher = new RadioButton() { Text = "Teacher", Name = "rdoTeacher", AutoSize = true };
            pnlType.Controls.Add(rdoStudent);
            pnlType.Controls.Add(rdoTeacher);
            grpType.Controls.Add(pnlType);

            pnlLeft.Controls.Add(lblFirstName);
            pnlLeft.Controls.Add(txtFirstName);
            pnlLeft.Controls.Add(lblLastName);
            pnlLeft.Controls.Add(txtLastName);
            pnlLeft.Controls.Add(lblAge);
            pnlLeft.Controls.Add(txtAge);
            pnlLeft.Controls.Add(grpType);

            // Middle column: student inputs
            var pnlStudent = new FlowLayoutPanel() { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
            var lblStudentId = new Label() { AutoSize = true, Text = "Student ID:" };
            var txtStudentId = new TextBox() { Width = 240, Name = "txtStudentId" };
            var lblMajor = new Label() { AutoSize = true, Text = "Major:" };
            var txtMajor = new TextBox() { Width = 240, Name = "txtMajor" };
            var lblGpa = new Label() { AutoSize = true, Text = "GPA:" };
            var txtGpa = new TextBox() { Width = 100, Name = "txtGpa" };
            pnlStudent.Controls.Add(lblStudentId);
            pnlStudent.Controls.Add(txtStudentId);
            pnlStudent.Controls.Add(lblMajor);
            pnlStudent.Controls.Add(txtMajor);
            pnlStudent.Controls.Add(lblGpa);
            pnlStudent.Controls.Add(txtGpa);

            // Right column: teacher inputs
            var pnlTeacher = new FlowLayoutPanel() { Dock = DockStyle.Fill, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false };
            var lblEmpId = new Label() { AutoSize = true, Text = "Employee ID:" };
            var txtEmpId = new TextBox() { Width = 240, Name = "txtEmpId" };
            var lblDepartment = new Label() { AutoSize = true, Text = "Department:" };
            var txtDepartment = new TextBox() { Width = 240, Name = "txtDepartment" };
            var lblSalary = new Label() { AutoSize = true, Text = "Salary:" };
            var txtSalary = new TextBox() { Width = 140, Name = "txtSalary" };
            pnlTeacher.Controls.Add(lblEmpId);
            pnlTeacher.Controls.Add(txtEmpId);
            pnlTeacher.Controls.Add(lblDepartment);
            pnlTeacher.Controls.Add(txtDepartment);
            pnlTeacher.Controls.Add(lblSalary);
            pnlTeacher.Controls.Add(txtSalary);

            tlpInputs.Controls.Add(pnlLeft, 0, 0);
            tlpInputs.Controls.Add(pnlStudent, 1, 0);
            tlpInputs.Controls.Add(pnlTeacher, 2, 0);

            // Buttons in a responsive flow panel
            var pnlButtons = new FlowLayoutPanel() { Dock = DockStyle.Top, AutoSize = true, FlowDirection = FlowDirection.LeftToRight, Padding = new Padding(8) };
            var btnCreate = new Button() { Width = 160, Height = 36, Text = "Create Object" };
            var btnClear = new Button() { Width = 160, Height = 36, Text = "Clear Inputs" };
            var btnDemo = new Button() { Width = 220, Height = 36, Text = "Create Demo 5 Objects" };
            pnlButtons.Controls.Add(btnCreate);
            pnlButtons.Controls.Add(btnClear);
            pnlButtons.Controls.Add(btnDemo);

            // ListBox to display created objects
            var lstObjects = new ListBox() { Dock = DockStyle.Fill, Name = "lstObjects" };
            lstObjects.Font = new Font(this.Font.FontFamily, 10.0f, FontStyle.Regular);
            lstObjects.HorizontalScrollbar = true;

            // Tooltips for UX assistance
            var tip = new ToolTip();
            tip.SetToolTip(txtFirstName, "Enter the person's given name (required).");
            tip.SetToolTip(txtLastName, "Enter the person's family name (required).");
            tip.SetToolTip(txtAge, "Enter age as an integer. If invalid, age will be clamped between 0 and 150.");
            tip.SetToolTip(txtGpa, "Enter GPA between 0.0 and 4.0. Non-numeric will default to 0.0.");
            tip.SetToolTip(txtSalary, "Enter salary as a number. Negative values will be set to 0.");

            // Wire up event handlers with clear, descriptive names
            btnCreate.Click += (s, e) =>
            {
                // Read common fields safely, with user-friendly validation messages.
                string firstName = txtFirstName.Text.Trim();
                string lastName = txtLastName.Text.Trim();
                if (string.IsNullOrEmpty(firstName) || string.IsNullOrEmpty(lastName))
                {
                    MessageBox.Show("Please enter both first and last name.", "Input Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(txtAge.Text.Trim(), out int age))
                {
                    MessageBox.Show("Age must be an integer. Defaulting to 0.", "Input Warning", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    age = 0;
                }

                // Create either Student or Teacher based on selection
                if (rdoStudent.Checked)
                {
                    string studentId = txtStudentId.Text.Trim();
                    string major = txtMajor.Text.Trim();
                    if (!double.TryParse(txtGpa.Text.Trim(), out double gpa)) gpa = 0.0;

                    var student = new Student(firstName, lastName, age, studentId, major, gpa);
                    _createdPeople.Add(student);
                    lstObjects.Items.Add(student.Display());
                }
                else
                {
                    string empId = txtEmpId.Text.Trim();
                    string department = txtDepartment.Text.Trim();
                    if (!decimal.TryParse(txtSalary.Text.Trim(), out decimal salary)) salary = 0m;

                    var teacher = new Teacher(firstName, lastName, age, empId, department, salary);
                    _createdPeople.Add(teacher);
                    lstObjects.Items.Add(teacher.Display());
                }

                // Provide clear feedback that object was created
                MessageBox.Show("Object created and added to the list.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            btnClear.Click += (s, e) =>
            {
                txtFirstName.Text = string.Empty;
                txtLastName.Text = string.Empty;
                txtAge.Text = string.Empty;
                txtStudentId.Text = string.Empty;
                txtMajor.Text = string.Empty;
                txtGpa.Text = string.Empty;
                txtEmpId.Text = string.Empty;
                txtDepartment.Text = string.Empty;
                txtSalary.Text = string.Empty;
            };

            btnDemo.Click += (s, e) =>
            {
                // Clear previous demo items and create 5 demo objects to show functionality
                _createdPeople.Clear();
                lstObjects.Items.Clear();

                var s1 = new Student("Alice", "Wong", 20, "S1001", "Computer Science", 3.8);
                var s2 = new Student("Bob", "Smith", 22, "S1002", "Mathematics", 3.5);
                var t1 = new Teacher("Carol", "Jones", 45, "E2001", "Physics", 85000m);
                var t2 = new Teacher("David", "Lee", 38, "E2002", "Computer Science", 78000m);
                var s3 = new Student("Eva", "Brown", 19, "S1003", "Biology", 3.9);

                _createdPeople.Add(s1); _createdPeople.Add(s2); _createdPeople.Add(t1); _createdPeople.Add(t2); _createdPeople.Add(s3);

                // Display all created demo objects using Display()
                foreach (var person in _createdPeople)
                {
                    lstObjects.Items.Add(person.Display());
                }

                MessageBox.Show("Demo objects created (5). You can inspect them in the list below.", "Demo Created", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            // Double-click list to show Identify and alternate displays
            lstObjects.DoubleClick += (s, e) =>
            {
                if (lstObjects.SelectedIndex < 0) return;
                var person = _createdPeople[lstObjects.SelectedIndex];

                // If implements IIdentifiable, show Identify() result
                if (person is IIdentifiable identifiable)
                {
                    MessageBox.Show(identifiable.Identify(), "Identify", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                // Also show the limited display example (2 attributes)
                MessageBox.Show(person.Display(2), "Partial Display", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            // Compose the main layout
            tlpMain.Controls.Add(tlpInputs, 0, 0);
            tlpMain.Controls.Add(pnlButtons, 0, 0);
            tlpMain.SetCellPosition(pnlButtons, new TableLayoutPanelCellPosition(0, 0));
            // Move inputs down so buttons appear above them
            tlpMain.SetCellPosition(tlpInputs, new TableLayoutPanelCellPosition(0, 0));
            // Add the list box in the second row
            tlpMain.Controls.Add(lstObjects, 0, 1);

            // Add main panel to the form
            this.Controls.Add(tlpMain);
        }
    }
}
