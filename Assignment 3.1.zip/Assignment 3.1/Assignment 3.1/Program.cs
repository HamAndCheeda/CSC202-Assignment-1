﻿// Entry point for the Windows Forms application.
// This program creates a simple UI that allows the user to create
// objects of two subclasses (Student and Teacher) that extend Person.
// It demonstrates encapsulation, interfaces, overloaded display methods,
// and a basic but clear UX for creating and viewing objects.

using System;
using System.Windows.Forms;

namespace Assignment_3._1
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new PersonCreator());
        }
    }
}
